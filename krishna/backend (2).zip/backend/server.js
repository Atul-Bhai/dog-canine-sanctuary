const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");

require("dotenv").config();

const app = express();

const PORT = process.env.PORT || 5000;

const MONGO_URI = process.env.MONGO_URI;
const JWT_SECRET = process.env.JWT_SECRET;

// =====================================================
// SECURITY CHECKS
// =====================================================

if (!MONGO_URI) {
  console.error("ERROR: MONGO_URI is missing in .env");
  process.exit(1);
}

if (!JWT_SECRET || JWT_SECRET.length < 32) {
  console.error(
    "ERROR: JWT_SECRET is missing or too short. Use a strong secret of at least 32 characters."
  );
  process.exit(1);
}

// =====================================================
// MIDDLEWARE
// =====================================================

// Security headers
app.use(
  helmet({
    crossOriginResourcePolicy: {
      policy: "cross-origin",
    },
  })
);

// CORS
const allowedOrigins = [
  "http://localhost:3000",
  process.env.FRONTEND_URL,
].filter(Boolean);

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow requests without Origin header
      // such as local server tools.
      if (!origin) {
        return callback(null, true);
      }

      if (allowedOrigins.includes(origin)) {
        return callback(null, true);
      }

      return callback(
        new Error("CORS policy: Origin not allowed")
      );
    },
    methods: ["GET", "POST", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
  })
);

// Limit JSON request size
app.use(
  express.json({
    limit: "10kb",
  })
);

// =====================================================
// RATE LIMITERS
// =====================================================

// Login protection
const loginLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: {
    success: false,
    message:
      "Too many login attempts. Please try again later.",
  },
});

// Signup protection
const signupLimiter = rateLimit({
  windowMs: 60 * 60 * 1000,
  limit: 10,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: {
    success: false,
    message:
      "Too many signup attempts. Please try again later.",
  },
});

// Public form protection
const publicFormLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 30,
  standardHeaders: "draft-7",
  legacyHeaders: false,
  message: {
    success: false,
    message:
      "Too many requests. Please try again later.",
  },
});

// =====================================================
// DATABASE
// =====================================================

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log("MongoDB connected successfully");

    app.listen(PORT, () => {
      console.log(
        `Backend server running on http://localhost:${PORT}`
      );
    });
  })
  .catch((error) => {
    console.error("MongoDB connection error:", error);
    process.exit(1);
  });

// =====================================================
// HELPERS
// =====================================================

const getAdminEmails = () => {
  return (process.env.ADMIN_EMAILS || "")
    .split(",")
    .map((email) => email.trim().toLowerCase())
    .filter(Boolean);
};

const isValidEmail = (email) => {
  if (typeof email !== "string") {
    return false;
  }

  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

const isValidObjectId = (id) => {
  return mongoose.Types.ObjectId.isValid(id);
};

const cleanString = (value) => {
  if (typeof value !== "string") {
    return "";
  }

  return value.trim();
};

// =====================================================
// USER SCHEMA
// =====================================================

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },

    email: {
      type: String,
      required: true,
      unique: true,
      lowercase: true,
      trim: true,
      maxlength: 254,
    },

    password: {
      type: String,
      required: true,
    },

    role: {
      type: String,
      enum: ["user", "admin"],
      default: "user",
    },
  },
  {
    timestamps: true,
  }
);

const User = mongoose.model("User", userSchema);

// =====================================================
// CONTACT SCHEMA
// =====================================================

const contactSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },

    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      maxlength: 254,
    },

    message: {
      type: String,
      required: true,
      trim: true,
      maxlength: 5000,
    },
  },
  {
    timestamps: true,
  }
);

const Contact = mongoose.model("Contact", contactSchema);

// =====================================================
// ADOPTION SCHEMA
// =====================================================

const adoptionSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },

    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      maxlength: 254,
    },

    phone: {
      type: String,
      required: true,
      trim: true,
      maxlength: 30,
    },

    dog: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },

    message: {
      type: String,
      trim: true,
      default: "",
      maxlength: 5000,
    },

    status: {
      type: String,
      enum: ["Pending", "Approved", "Rejected"],
      default: "Pending",
    },
  },
  {
    timestamps: true,
  }
);

const Adoption = mongoose.model(
  "Adoption",
  adoptionSchema
);

// =====================================================
// VOLUNTEER SCHEMA
// =====================================================

const volunteerSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      maxlength: 100,
    },

    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      maxlength: 254,
    },

    phone: {
      type: String,
      required: true,
      trim: true,
      maxlength: 30,
    },

    activity: {
      type: String,
      required: true,
      trim: true,
      maxlength: 200,
    },
  },
  {
    timestamps: true,
  }
);

const Volunteer = mongoose.model(
  "Volunteer",
  volunteerSchema
);

// =====================================================
// JWT AUTHENTICATION
// =====================================================

const authenticateToken = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;

    if (!authHeader) {
      return res.status(401).json({
        success: false,
        message: "Access token required",
      });
    }

    if (!authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        success: false,
        message: "Invalid authorization format",
      });
    }

    const token = authHeader.slice(7).trim();

    if (!token) {
      return res.status(401).json({
        success: false,
        message: "Access token required",
      });
    }

    jwt.verify(
      token,
      JWT_SECRET,
      (error, decoded) => {
        if (error) {
          return res.status(403).json({
            success: false,
            message: "Invalid or expired token",
          });
        }

        req.user = decoded;
        next();
      }
    );
  } catch (error) {
    console.error("Authentication error:", error);

    return res.status(500).json({
      success: false,
      message: "Authentication failed",
    });
  }
};

// =====================================================
// ADMIN AUTHENTICATION
// =====================================================

const requireAdmin = (req, res, next) => {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: "Authentication required",
    });
  }

  if (
    String(req.user.role).toLowerCase() !==
    "admin"
  ) {
    return res.status(403).json({
      success: false,
      message: "Admin access required",
    });
  }

  next();
};

// =====================================================
// HOME
// =====================================================

app.get("/", (req, res) => {
  res.json({
    success: true,
    message: "Dog Canine Sanctuary backend is running",
  });
});

// =====================================================
// ADOPTION
// =====================================================

// PUBLIC - SUBMIT APPLICATION

app.post(
  "/api/adoption",
  publicFormLimiter,
  async (req, res) => {
    try {
      const name = cleanString(req.body.name);
      const email = cleanString(req.body.email).toLowerCase();
      const phone = cleanString(req.body.phone);
      const dog = cleanString(req.body.dog);
      const message = cleanString(req.body.message);

      if (!name || !email || !phone || !dog) {
        return res.status(400).json({
          success: false,
          message:
            "Name, email, phone and dog are required",
        });
      }

      if (!isValidEmail(email)) {
        return res.status(400).json({
          success: false,
          message: "Please provide a valid email address",
        });
      }

      if (name.length > 100 || dog.length > 100) {
        return res.status(400).json({
          success: false,
          message: "Name or dog name is too long",
        });
      }

      if (phone.length > 30) {
        return res.status(400).json({
          success: false,
          message: "Phone number is too long",
        });
      }

      if (message.length > 5000) {
        return res.status(400).json({
          success: false,
          message: "Message is too long",
        });
      }

      const application =
        await Adoption.create({
          name,
          email,
          phone,
          dog,
          message,
          status: "Pending",
        });

      res.status(201).json({
        success: true,
        message:
          "Adoption application submitted successfully",
        application,
      });
    } catch (error) {
      console.error(
        "Adoption POST error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to submit adoption application",
      });
    }
  }
);

// ADMIN - GET APPLICATIONS

app.get(
  "/api/adoption",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const applications =
        await Adoption.find().sort({
          createdAt: -1,
        });

      res.json({
        success: true,
        applications,
      });
    } catch (error) {
      console.error(
        "Adoption GET error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to load adoption applications",
      });
    }
  }
);

// ADMIN - UPDATE STATUS

app.patch(
  "/api/adoption/:id/status",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      if (!isValidObjectId(req.params.id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid application ID",
        });
      }

      const { status } = req.body;

      const allowedStatuses = [
        "Pending",
        "Approved",
        "Rejected",
      ];

      if (!allowedStatuses.includes(status)) {
        return res.status(400).json({
          success: false,
          message: "Invalid application status",
        });
      }

      const application =
        await Adoption.findByIdAndUpdate(
          req.params.id,
          { status },
          {
            new: true,
            runValidators: true,
          }
        );

      if (!application) {
        return res.status(404).json({
          success: false,
          message:
            "Adoption application not found",
        });
      }

      res.json({
        success: true,
        message:
          "Application status updated successfully",
        application,
      });
    } catch (error) {
      console.error(
        "Adoption status error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to update application status",
      });
    }
  }
);

// ADMIN - DELETE APPLICATION

app.delete(
  "/api/adoption/:id",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      if (!isValidObjectId(req.params.id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid application ID",
        });
      }

      const application =
        await Adoption.findByIdAndDelete(
          req.params.id
        );

      if (!application) {
        return res.status(404).json({
          success: false,
          message:
            "Adoption application not found",
        });
      }

      res.json({
        success: true,
        message:
          "Adoption application deleted successfully",
      });
    } catch (error) {
      console.error(
        "Adoption DELETE error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to delete adoption application",
      });
    }
  }
);

// =====================================================
// VOLUNTEER
// =====================================================

// PUBLIC - SUBMIT VOLUNTEER REQUEST

app.post(
  "/api/volunteer",
  publicFormLimiter,
  async (req, res) => {
    try {
      const name = cleanString(req.body.name);
      const email = cleanString(req.body.email).toLowerCase();
      const phone = cleanString(req.body.phone);
      const activity = cleanString(req.body.activity);

      if (!name || !email || !phone || !activity) {
        return res.status(400).json({
          success: false,
          message:
            "Name, email, phone and activity are required",
        });
      }

      if (!isValidEmail(email)) {
        return res.status(400).json({
          success: false,
          message: "Please provide a valid email address",
        });
      }

      if (name.length > 100) {
        return res.status(400).json({
          success: false,
          message: "Name is too long",
        });
      }

      if (phone.length > 30) {
        return res.status(400).json({
          success: false,
          message: "Phone number is too long",
        });
      }

      if (activity.length > 200) {
        return res.status(400).json({
          success: false,
          message: "Activity is too long",
        });
      }

      const volunteer =
        await Volunteer.create({
          name,
          email,
          phone,
          activity,
        });

      res.status(201).json({
        success: true,
        message:
          "Volunteer request submitted successfully",
        volunteer,
      });
    } catch (error) {
      console.error(
        "Volunteer POST error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to submit volunteer request",
      });
    }
  }
);

// ADMIN - GET VOLUNTEERS

app.get(
  "/api/volunteer",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const applications =
        await Volunteer.find().sort({
          createdAt: -1,
        });

      res.json({
        success: true,
        applications,
      });
    } catch (error) {
      console.error(
        "Volunteer GET error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to load volunteer requests",
      });
    }
  }
);

// ADMIN - DELETE VOLUNTEER

app.delete(
  "/api/volunteer/:id",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      if (!isValidObjectId(req.params.id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid volunteer ID",
        });
      }

      const volunteer =
        await Volunteer.findByIdAndDelete(
          req.params.id
        );

      if (!volunteer) {
        return res.status(404).json({
          success: false,
          message:
            "Volunteer request not found",
        });
      }

      res.json({
        success: true,
        message:
          "Volunteer request deleted successfully",
      });
    } catch (error) {
      console.error(
        "Volunteer DELETE error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to delete volunteer request",
      });
    }
  }
);

// =====================================================
// CONTACT
// =====================================================

// PUBLIC - SEND MESSAGE

app.post(
  "/api/contact",
  publicFormLimiter,
  async (req, res) => {
    try {
      const name = cleanString(req.body.name);
      const email = cleanString(req.body.email).toLowerCase();
      const message = cleanString(req.body.message);

      if (!name || !email || !message) {
        return res.status(400).json({
          success: false,
          message:
            "Name, email and message are required",
        });
      }

      if (!isValidEmail(email)) {
        return res.status(400).json({
          success: false,
          message: "Please provide a valid email address",
        });
      }

      if (name.length > 100) {
        return res.status(400).json({
          success: false,
          message: "Name is too long",
        });
      }

      if (message.length > 5000) {
        return res.status(400).json({
          success: false,
          message: "Message is too long",
        });
      }

      const contact =
        await Contact.create({
          name,
          email,
          message,
        });

      res.status(201).json({
        success: true,
        message: "Message sent successfully",
        contact,
      });
    } catch (error) {
      console.error(
        "Contact POST error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to send contact message",
      });
    }
  }
);

// ADMIN - GET MESSAGES

app.get(
  "/api/contact",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      const messages =
        await Contact.find().sort({
          createdAt: -1,
        });

      res.json({
        success: true,
        messages,
      });
    } catch (error) {
      console.error(
        "Contact GET error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to load contact messages",
      });
    }
  }
);

// ADMIN - DELETE MESSAGE

app.delete(
  "/api/contact/:id",
  authenticateToken,
  requireAdmin,
  async (req, res) => {
    try {
      if (!isValidObjectId(req.params.id)) {
        return res.status(400).json({
          success: false,
          message: "Invalid contact message ID",
        });
      }

      const message =
        await Contact.findByIdAndDelete(
          req.params.id
        );

      if (!message) {
        return res.status(404).json({
          success: false,
          message:
            "Contact message not found",
        });
      }

      res.json({
        success: true,
        message:
          "Contact message deleted successfully",
      });
    } catch (error) {
      console.error(
        "Contact DELETE error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Failed to delete contact message",
      });
    }
  }
);

// =====================================================
// AUTH - SIGNUP
// =====================================================

app.post(
  "/api/auth/signup",
  signupLimiter,
  async (req, res) => {
    try {
      const name = cleanString(req.body.name);
      const email = cleanString(req.body.email).toLowerCase();
      const password =
        typeof req.body.password === "string"
          ? req.body.password
          : "";

      if (!name || !email || !password) {
        return res.status(400).json({
          success: false,
          message:
            "Name, email and password are required",
        });
      }

      if (!isValidEmail(email)) {
        return res.status(400).json({
          success: false,
          message: "Please provide a valid email address",
        });
      }

      if (name.length > 100) {
        return res.status(400).json({
          success: false,
          message: "Name is too long",
        });
      }

      if (password.length < 6) {
        return res.status(400).json({
          success: false,
          message:
            "Password must be at least 6 characters",
        });
      }

      if (password.length > 128) {
        return res.status(400).json({
          success: false,
          message: "Password is too long",
        });
      }

      const existingUser =
        await User.findOne({
          email,
        });

      if (existingUser) {
        return res.status(409).json({
          success: false,
          message:
            "An account with this email already exists",
        });
      }

      const hashedPassword =
        await bcrypt.hash(password, 10);

      const adminEmails =
        getAdminEmails();

      const role =
        adminEmails.includes(email)
          ? "admin"
          : "user";

      const user =
        await User.create({
          name,
          email,
          password: hashedPassword,
          role,
        });

      res.status(201).json({
        success: true,
        message:
          "Account created successfully",
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: user.role,
        },
      });
    } catch (error) {
      console.error(
        "Signup error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Unable to create account",
      });
    }
  }
);

// =====================================================
// AUTH - LOGIN
// =====================================================

app.post(
  "/api/auth/login",
  loginLimiter,
  async (req, res) => {
    try {
      const email = cleanString(req.body.email).toLowerCase();
      const password =
        typeof req.body.password === "string"
          ? req.body.password
          : "";

      if (!email || !password) {
        return res.status(400).json({
          success: false,
          message:
            "Email and password are required",
        });
      }

      if (!isValidEmail(email)) {
        return res.status(400).json({
          success: false,
          message: "Please provide a valid email address",
        });
      }

      if (password.length > 128) {
        return res.status(400).json({
          success: false,
          message: "Invalid email or password",
        });
      }

      const user =
        await User.findOne({
          email,
        });

      if (!user) {
        return res.status(401).json({
          success: false,
          message:
            "Invalid email or password",
        });
      }

      const isMatch =
        await bcrypt.compare(
          password,
          user.password
        );

      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message:
            "Invalid email or password",
        });
      }

      const adminEmails =
        getAdminEmails();

      const userRole =
        adminEmails.includes(email)
          ? "admin"
          : user.role || "user";

      const token =
        jwt.sign(
          {
            id: user._id.toString(),
            email: user.email,
            role: userRole,
          },
          JWT_SECRET,
          {
            expiresIn: "7d",
          }
        );

      res.json({
        success: true,
        message: "Login successful",
        token,
        user: {
          id: user._id,
          name: user.name,
          email: user.email,
          role: userRole,
        },
      });
    } catch (error) {
      console.error(
        "Login error:",
        error
      );

      res.status(500).json({
        success: false,
        message:
          "Unable to login",
      });
    }
  }
);

// =====================================================
// 404
// =====================================================

app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: "API route not found",
  });
});

// =====================================================
// GLOBAL ERROR HANDLER
// =====================================================

app.use((error, req, res, next) => {
  console.error("Global server error:", error);

  if (error.message?.startsWith("CORS policy")) {
    return res.status(403).json({
      success: false,
      message: "Origin not allowed",
    });
  }

  if (error.type === "entity.too.large") {
    return res.status(413).json({
      success: false,
      message: "Request body is too large",
    });
  }

  return res.status(500).json({
    success: false,
    message: "Internal server error",
  });
});
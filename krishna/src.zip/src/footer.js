function Footer() {
  return (
    <footer className="bg-stone-900 text-white">
      <div className="mx-auto max-w-7xl px-6 py-14 md:px-10">

        {/* Footer Content */}
        <div className="text-center">

          {/* Logo / Name */}
          <h3 className="text-2xl font-extrabold text-white">
            🐶 Dog Canine Sanctuary
          </h3>

          {/* Description */}
          <p className="mx-auto mt-4 max-w-xl text-stone-300">
            Giving rescued dogs a second chance at a happy life.
          </p>

          {/* Social Icons */}
          <div className="mt-7 flex justify-center gap-4">

            <button
              type="button"
              aria-label="Facebook"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-stone-800 text-xl transition duration-300 hover:-translate-y-1 hover:bg-amber-600"
            >
              📘
            </button>

            <button
              type="button"
              aria-label="Instagram"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-stone-800 text-xl transition duration-300 hover:-translate-y-1 hover:bg-amber-600"
            >
              📸
            </button>

            <button
              type="button"
              aria-label="Twitter"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-stone-800 text-xl transition duration-300 hover:-translate-y-1 hover:bg-amber-600"
            >
              🐦
            </button>

            <button
              type="button"
              aria-label="YouTube"
              className="flex h-11 w-11 items-center justify-center rounded-full bg-stone-800 text-xl transition duration-300 hover:-translate-y-1 hover:bg-amber-600"
            >
              ▶️
            </button>

          </div>

          {/* Divider */}
          <div className="my-8 h-px bg-stone-700"></div>

          {/* Copyright */}
          <p className="text-sm text-stone-400">
            © 2026 Dog Canine Sanctuary. All Rights Reserved.
          </p>

        </div>

      </div>
    </footer>
  );
}

export default Footer;
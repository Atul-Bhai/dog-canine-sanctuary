import { useState } from "react";
import "./contact.css";

function Contact() {
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();

    setSent(false);
    setError("");
    setLoading(true);

    const form = new FormData(e.target);

    const data = {
      name: String(form.get("name") || "").trim(),
      email: String(form.get("email") || "").trim(),
      message: String(form.get("message") || "").trim(),
    };

    try {
      const response = await fetch(
        "http://localhost:5000/api/contact",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(
          result.message || "Unable to send your message."
        );
      }

      setSent(true);
      e.target.reset();

      window.scrollTo({
        top: 0,
        behavior: "smooth",
      });
    } catch (error) {
      console.error("Contact error:", error);

      setError(
        error.message ||
          "Server connection failed. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="contact-page">
      <div className="contact-container">

        {/* HERO */}
        <div className="contact-header">

          <div className="contact-icon">
            📞
          </div>

          <div className="contact-eyebrow">
            GET IN TOUCH
          </div>

          <h1>
            Contact <span>Us</span>
          </h1>

          <p>
            Have a question, want to help, or simply want
            to know more about our rescued dogs?
            We would love to hear from you.
          </p>

        </div>

        {/* MAIN CONTENT */}
        <div className="contact-layout">

          {/* CONTACT INFORMATION */}
          <div className="contact-info-card">

            <div className="contact-card-top">
              <span>CONTACT INFORMATION</span>

              <h2>
                Get In Touch 🐾
              </h2>

              <p>
                Our sanctuary team is always happy to
                connect with people who care about rescued
                dogs.
              </p>
            </div>

            <div className="contact-info-list">

              <div className="contact-info-item">

                <div className="contact-info-icon">
                  📍
                </div>

                <div>
                  <span>OUR LOCATION</span>
                  <strong>
                    Ahmedabad, Gujarat, India
                  </strong>
                </div>

              </div>

              <div className="contact-info-item">

                <div className="contact-info-icon">
                  📞
                </div>

                <div>
                  <span>PHONE</span>
                  <strong>
                    +91 98765 43210
                  </strong>
                </div>

              </div>

              <div className="contact-info-item">

                <div className="contact-info-icon">
                  📧
                </div>

                <div>
                  <span>EMAIL</span>
                  <strong>
                    info@dogcaninesanctuary.com
                  </strong>
                </div>

              </div>

              <div className="contact-info-item">

                <div className="contact-info-icon">
                  🕐
                </div>

                <div>
                  <span>OPENING HOURS</span>
                  <strong>
                    Monday - Sunday
                  </strong>
                  <small>
                    9:00 AM - 6:00 PM
                  </small>
                </div>

              </div>

            </div>

            <div className="contact-help-box">

              <div className="contact-help-icon">
                ❤️
              </div>

              <div>
                <strong>
                  Every message matters
                </strong>

                <p>
                  Your questions, suggestions and support
                  help us improve life for our rescued dogs.
                </p>
              </div>

            </div>

          </div>

          {/* CONTACT FORM */}
          <div className="contact-form-card">

            <div className="contact-form-heading">

              <span>LEAVE US A MESSAGE</span>

              <h2>
                We'd love to hear from you
              </h2>

              <p>
                Fill in the form below and our team will
                get back to you as soon as possible.
              </p>

            </div>

            {/* SUCCESS */}
            {sent && (
              <div className="contact-success">

                <div className="contact-success-icon">
                  ✓
                </div>

                <div>
                  <strong>
                    Your message has been sent successfully!
                  </strong>

                  <p>
                    Thank you for reaching out.
                    Our team will get back to you soon.
                  </p>
                </div>

              </div>
            )}

            {/* ERROR */}
            {error && (
              <div className="contact-error">

                <div className="contact-error-icon">
                  !
                </div>

                <div>
                  <strong>
                    Message could not be sent.
                  </strong>

                  <p>
                    {error}
                  </p>
                </div>

              </div>
            )}

            <form onSubmit={submit}>

              <div className="contact-field">

                <label htmlFor="contact-name">
                  Your Name <span>*</span>
                </label>

                <input
                  id="contact-name"
                  type="text"
                  name="name"
                  placeholder="Enter your full name"
                  autoComplete="name"
                  required
                />

              </div>

              <div className="contact-field">

                <label htmlFor="contact-email">
                  Your Email <span>*</span>
                </label>

                <input
                  id="contact-email"
                  type="email"
                  name="email"
                  placeholder="you@example.com"
                  autoComplete="email"
                  required
                />

              </div>

              <div className="contact-field">

                <label htmlFor="contact-message">
                  Your Message <span>*</span>
                </label>

                <textarea
                  id="contact-message"
                  name="message"
                  rows="7"
                  placeholder="Write your message here..."
                  required
                ></textarea>

              </div>

              <button
                type="submit"
                className="contact-submit-btn"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="contact-spinner"></span>
                    Sending...
                  </>
                ) : (
                  <>
                    Send Message
                    <span>→</span>
                  </>
                )}
              </button>

            </form>

            <div className="contact-privacy">
              🔒 Your information is kept private and used
              only to respond to your message.
            </div>

          </div>

        </div>

        {/* BOTTOM NOTE */}
        <div className="contact-bottom-note">
          <span>🐶</span>
          <p>
            Thank you for caring about our rescued dogs.
          </p>
        </div>

      </div>
    </section>
  );
}

export default Contact;
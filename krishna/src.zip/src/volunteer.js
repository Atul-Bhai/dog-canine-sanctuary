import { useState } from "react";
import "./volunteer.css";

function Volunteer() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submitForm = async (e) => {
    e.preventDefault();

    setSubmitted(false);
    setError("");
    setLoading(true);

    const form = new FormData(e.target);

    const data = {
      name: String(form.get("name") || "").trim(),
      email: String(form.get("email") || "").trim(),
      phone: String(form.get("phone") || "").trim(),
      activity: String(form.get("activity") || "").trim(),
    };

    try {
      const response = await fetch(
        "http://localhost:5000/api/volunteer",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(
          result.message ||
            "Unable to submit volunteer registration."
        );
      }

      setSubmitted(true);
      e.target.reset();
    } catch (error) {
      console.error("Volunteer error:", error);

      setError(
        error.message ||
          "Unable to connect to the sanctuary server."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="volunteer-page">
      <div className="volunteer-container">

        {/* HERO */}
        <div className="volunteer-header">

          <div className="volunteer-icon">
            🐾
          </div>

          <div className="volunteer-eyebrow">
            HELP • CARE • MAKE A DIFFERENCE
          </div>

          <h1>
            Become a Volunteer
          </h1>

          <p>
            Join our sanctuary family and help us
            give rescued dogs the love, care and
            second chance they deserve.
          </p>

        </div>

        {/* FORM CARD */}
        <div className="volunteer-card">

          <div className="volunteer-card-header">

            <div>
              <span>
                VOLUNTEER REGISTRATION
              </span>

              <h2>
                Join our sanctuary family
              </h2>

              <p>
                Tell us a little about yourself and
                choose how you would like to help.
              </p>
            </div>

            <div className="volunteer-step">
              <strong>01</strong>
              <span>REGISTER</span>
            </div>

          </div>

          {/* SUCCESS */}
          {submitted && (
            <div className="volunteer-success">

              <div className="volunteer-success-icon">
                ✓
              </div>

              <div>
                <strong>
                  Volunteer registration submitted successfully!
                </strong>

                <p>
                  Thank you for joining our mission.
                  Our sanctuary team will review your
                  registration and contact you soon.
                </p>
              </div>

            </div>
          )}

          {/* ERROR */}
          {error && (
            <div className="volunteer-form-error">

              <div className="volunteer-error-icon">
                !
              </div>

              <div>
                <strong>
                  We couldn't submit your registration.
                </strong>

                <p>
                  {error}
                </p>
              </div>

            </div>
          )}

          <form onSubmit={submitForm}>

            {/* YOUR INFORMATION */}
            <div className="volunteer-section-title">

              <span className="volunteer-section-number">
                01
              </span>

              <div>
                <h3>
                  Your Information
                </h3>

                <p>
                  Please provide your basic contact details.
                </p>
              </div>

            </div>

            <div className="volunteer-form-grid">

              {/* NAME */}
              <div className="volunteer-field">

                <label htmlFor="volunteer-name">
                  Full Name
                  <span>*</span>
                </label>

                <input
                  id="volunteer-name"
                  type="text"
                  name="name"
                  placeholder="Enter your full name"
                  autoComplete="name"
                  required
                />

              </div>

              {/* EMAIL */}
              <div className="volunteer-field">

                <label htmlFor="volunteer-email">
                  Email Address
                  <span>*</span>
                </label>

                <input
                  id="volunteer-email"
                  type="email"
                  name="email"
                  placeholder="you@example.com"
                  autoComplete="email"
                  required
                />

              </div>

              {/* PHONE */}
              <div className="volunteer-field">

                <label htmlFor="volunteer-phone">
                  Phone Number
                  <span>*</span>
                </label>

                <input
                  id="volunteer-phone"
                  type="tel"
                  name="phone"
                  placeholder="Enter your phone number"
                  autoComplete="tel"
                  required
                />

              </div>

              {/* ACTIVITY */}
              <div className="volunteer-field">

                <label htmlFor="volunteer-activity">
                  Select Activity
                  <span>*</span>
                </label>

                <select
                  id="volunteer-activity"
                  name="activity"
                  defaultValue=""
                  required
                >
                  <option value="" disabled>
                    Select an activity
                  </option>

                  <option value="Dog Care">
                    Dog Care
                  </option>

                  <option value="Dog Walking">
                    Dog Walking
                  </option>

                  <option value="Food Distribution">
                    Food Distribution
                  </option>

                  <option value="Rescue Support">
                    Rescue Support
                  </option>

                  <option value="Fundraising">
                    Fundraising
                  </option>
                </select>

              </div>

            </div>

            {/* WHY VOLUNTEER */}
            <div className="volunteer-help-box">

              <div className="volunteer-help-icon">
                ❤️
              </div>

              <div>
                <strong>
                  Every helping hand matters
                </strong>

                <p>
                  Whether you care for dogs, help with
                  walks, food distribution, rescue support
                  or fundraising, your time can make a
                  real difference in a rescued dog's life.
                </p>
              </div>

            </div>

            {/* SUBMIT */}
            <div className="volunteer-submit-area">

              <div className="volunteer-privacy">
                <span>🔒</span>

                <p>
                  Your information is used only for
                  volunteer registration and communication.
                </p>
              </div>

              <button
                type="submit"
                className="volunteer-submit-btn"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="volunteer-spinner"></span>
                    Submitting...
                  </>
                ) : (
                  <>
                    Register As Volunteer
                    <span>→</span>
                  </>
                )}
              </button>

            </div>

          </form>

        </div>

        {/* BOTTOM NOTE */}
        <div className="volunteer-bottom-note">

          <span>🐶</span>

          <p>
            Thank you for giving your time, energy
            and heart to our rescued dogs.
          </p>

        </div>

      </div>
    </section>
  );
}

export default Volunteer;
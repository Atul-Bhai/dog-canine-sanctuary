import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";

function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const location = useLocation();
  const navigate = useNavigate();

  const closeMenu = () => {
    setIsOpen(false);
  };

  // =========================
  // GET CURRENT USER
  // =========================

  let user = null;

  try {
    user = JSON.parse(localStorage.getItem("user"));
  } catch (error) {
    user = null;
  }

  const isLoggedIn = !!user;
  const isAdmin = user?.role === "admin";

  // =========================
  // LOGOUT
  // =========================

  const handleLogout = () => {
    localStorage.removeItem("user");
    closeMenu();
    navigate("/login");
  };

  // =========================
  // NAVIGATION ITEMS
  // =========================

  const menuItems = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Care", path: "/care" },
    { name: "Rescue", path: "/rescue" },
    { name: "Adoption", path: "/adoption" },
    { name: "Donate", path: "/donate" },
    { name: "Volunteer", path: "/volunteer" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <>
      {/* =========================
          NAVBAR
      ========================= */}

      <nav className="fixed top-0 left-0 w-full z-50 px-3 sm:px-5 lg:px-8 pt-3">

        <div
          className="
            max-w-7xl
            mx-auto
            bg-white/95
            backdrop-blur-xl
            border border-gray-200/70
            rounded-2xl
            shadow-[0_10px_35px_rgba(15,23,42,0.10)]
          "
        >

          <div className="px-4 sm:px-6 lg:px-7">

            <div className="flex items-center justify-between h-[76px]">

              {/* =========================
                  PREMIUM LOGO
              ========================= */}

              <Link
                to="/"
                onClick={closeMenu}
                className="
                  flex
                  items-center
                  gap-3
                  flex-shrink-0
                  group
                "
              >

                {/* Logo Image */}

                <div
                  className="
                    relative
                    w-12
                    h-12
                    sm:w-14
                    sm:h-14
                    rounded-2xl
                    overflow-hidden
                    bg-[#172033]
                    shadow-[0_6px_18px_rgba(23,32,51,0.22)]
                    border
                    border-white
                    transition-all
                    duration-300
                    group-hover:scale-105
                    group-hover:shadow-[0_8px_22px_rgba(217,120,32,0.25)]
                  "
                >

                  <img
                    src="/logo.jpeg"
                    alt="Dog Canine Sanctuary Logo"
                    className="
                      w-full
                      h-full
                      object-cover
                      block
                    "
                  />

                  {/* Small orange accent */}

                  <span
                    className="
                      absolute
                      bottom-0
                      right-0
                      w-3
                      h-3
                      bg-orange-500
                      rounded-full
                      border-2
                      border-white
                    "
                  />

                </div>

                {/* Brand Name */}

                <div className="leading-none">

                  <div
                    className="
                      text-[17px]
                      sm:text-[20px]
                      font-extrabold
                      tracking-[-0.5px]
                      text-[#172033]
                      group-hover:text-orange-500
                      transition-colors
                    "
                  >
                    Dog Canine
                  </div>

                  <div
                    className="
                      mt-1.5
                      text-[9px]
                      sm:text-[11px]
                      font-extrabold
                      tracking-[3px]
                      text-[#d98a32]
                    "
                  >
                    SANCTUARY
                  </div>

                </div>

              </Link>

              {/* =========================
                  DESKTOP NAVIGATION
              ========================= */}

              <div className="hidden xl:flex items-center gap-1 ml-8">

                {menuItems.map((item) => {

                  const isActive = location.pathname === item.path;

                  return (
                    <Link
                      key={item.name}
                      to={item.path}
                      className={`
                        relative
                        px-3
                        py-2.5
                        rounded-xl
                        text-[14px]
                        font-semibold
                        transition-all
                        duration-300
                        group
                        ${
                          isActive
                            ? "text-orange-500 bg-orange-50"
                            : "text-gray-600 hover:text-orange-500 hover:bg-orange-50"
                        }
                      `}
                    >

                      {item.name}

                      {/* Active underline */}

                      <span
                        className={`
                          absolute
                          left-3
                          right-3
                          bottom-1
                          h-[2px]
                          bg-orange-500
                          rounded-full
                          transition-all
                          duration-300
                          ${
                            isActive
                              ? "opacity-100 scale-x-100"
                              : "opacity-0 scale-x-0 group-hover:opacity-100 group-hover:scale-x-100"
                          }
                        `}
                      />

                    </Link>
                  );
                })}

              </div>

              {/* =========================
                  RIGHT SIDE
              ========================= */}

              <div className="hidden lg:flex items-center gap-2 ml-auto">

                {isLoggedIn ? (
                  <>

                    {/* Admin */}

                    {isAdmin && (
                      <Link
                        to="/admin"
                        className="
                          group
                          flex
                          items-center
                          gap-2
                          px-4
                          py-2.5
                          rounded-xl
                          bg-gradient-to-r
                          from-orange-500
                          to-amber-500
                          text-white
                          text-[13px]
                          font-bold
                          shadow-[0_6px_18px_rgba(234,126,34,0.25)]
                          hover:shadow-[0_8px_24px_rgba(234,126,34,0.35)]
                          hover:-translate-y-0.5
                          transition-all
                        "
                      >
                        <span className="text-base">♛</span>
                        <span>Admin</span>
                      </Link>
                    )}

                    {/* Logout */}

                    <button
                      type="button"
                      onClick={handleLogout}
                      className="
                        flex
                        items-center
                        gap-2
                        px-4
                        py-2.5
                        rounded-xl
                        border
                        border-red-200
                        bg-red-50
                        text-red-500
                        text-[13px]
                        font-bold
                        hover:bg-red-500
                        hover:text-white
                        hover:border-red-500
                        transition-all
                      "
                    >
                      <span>↪</span>
                      Logout
                    </button>

                  </>
                ) : (
                  <>

                    {/* Login */}

                    <Link
                      to="/login"
                      className="
                        px-4
                        py-2.5
                        rounded-xl
                        text-[13px]
                        font-bold
                        text-gray-700
                        hover:text-orange-500
                        hover:bg-orange-50
                        transition-all
                      "
                    >
                      Login
                    </Link>

                    {/* Sign Up */}

                    <Link
                      to="/signup"
                      className="
                        px-5
                        py-2.5
                        rounded-xl
                        bg-gradient-to-r
                        from-orange-500
                        to-amber-500
                        text-white
                        text-[13px]
                        font-bold
                        shadow-[0_6px_18px_rgba(234,126,34,0.25)]
                        hover:shadow-[0_8px_24px_rgba(234,126,34,0.35)]
                        hover:-translate-y-0.5
                        transition-all
                      "
                    >
                      Sign Up
                    </Link>

                  </>
                )}

              </div>

              {/* =========================
                  MOBILE MENU BUTTON
              ========================= */}

              <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className="
                  xl:hidden
                  ml-auto
                  w-11
                  h-11
                  flex
                  items-center
                  justify-center
                  rounded-xl
                  bg-orange-50
                  text-orange-500
                  hover:bg-orange-500
                  hover:text-white
                  transition-all
                "
                aria-label="Toggle menu"
              >

                {isOpen ? (
                  <span className="text-2xl font-light">
                    ×
                  </span>
                ) : (
                  <span className="text-xl">
                    ☰
                  </span>
                )}

              </button>

            </div>

            {/* =========================
                MOBILE MENU
            ========================= */}

            {isOpen && (
              <div
                className="
                  xl:hidden
                  border-t
                  border-gray-100
                  py-4
                  animate-[fadeIn_0.2s_ease-out]
                "
              >

                <div className="flex flex-col gap-1">

                  {menuItems.map((item) => {

                    const isActive =
                      location.pathname === item.path;

                    return (
                      <Link
                        key={item.name}
                        to={item.path}
                        onClick={closeMenu}
                        className={`
                          px-4
                          py-3
                          rounded-xl
                          font-semibold
                          text-sm
                          transition-all
                          ${
                            isActive
                              ? "bg-orange-50 text-orange-500"
                              : "text-gray-700 hover:bg-orange-50 hover:text-orange-500"
                          }
                        `}
                      >
                        {item.name}
                      </Link>
                    );
                  })}

                  {/* =========================
                      MOBILE USER ACTIONS
                  ========================= */}

                  <div className="border-t border-gray-100 mt-3 pt-4">

                    {isLoggedIn ? (
                      <div className="flex flex-col gap-2">

                        {/* Admin */}

                        {isAdmin && (
                          <Link
                            to="/admin"
                            onClick={closeMenu}
                            className="
                              w-full
                              text-center
                              px-4
                              py-3
                              rounded-xl
                              bg-gradient-to-r
                              from-orange-500
                              to-amber-500
                              text-white
                              font-bold
                              shadow-md
                            "
                          >
                            ♛ Admin Dashboard
                          </Link>
                        )}

                        {/* Logout */}

                        <button
                          type="button"
                          onClick={handleLogout}
                          className="
                            w-full
                            px-4
                            py-3
                            rounded-xl
                            border
                            border-red-200
                            bg-red-50
                            text-red-500
                            font-bold
                            hover:bg-red-500
                            hover:text-white
                            transition-all
                          "
                        >
                          ↪ Logout
                        </button>

                      </div>
                    ) : (
                      <div className="grid grid-cols-2 gap-2">

                        <Link
                          to="/login"
                          onClick={closeMenu}
                          className="
                            text-center
                            px-4
                            py-3
                            rounded-xl
                            bg-orange-500
                            text-white
                            font-bold
                            hover:bg-orange-600
                            transition-all
                          "
                        >
                          Login
                        </Link>

                        <Link
                          to="/signup"
                          onClick={closeMenu}
                          className="
                            text-center
                            px-4
                            py-3
                            rounded-xl
                            border-2
                            border-orange-500
                            text-orange-500
                            font-bold
                            hover:bg-orange-500
                            hover:text-white
                            transition-all
                          "
                        >
                          Sign Up
                        </Link>

                      </div>
                    )}

                  </div>

                </div>

              </div>
            )}

          </div>

        </div>

      </nav>
    </>
  );
}

export default Navbar;
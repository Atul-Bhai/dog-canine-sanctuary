import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Message.css";

const API = "http://localhost:5000/api";

function Message() {
  const navigate = useNavigate();

  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [deletingId, setDeletingId] = useState(null);
  const [search, setSearch] = useState("");

  // =====================================================
  // GET AUTH TOKEN
  // =====================================================

  const getAuthToken = useCallback(() => {
    return (
      localStorage.getItem("token") ||
      localStorage.getItem("adminToken") ||
      null
    );
  }, []);

  // =====================================================
  // AUTHENTICATED FETCH
  // =====================================================

  const authenticatedFetch = useCallback(
    async (url, options = {}) => {
      const token = getAuthToken();

      if (!token) {
        localStorage.removeItem("user");
        localStorage.removeItem("token");
        localStorage.removeItem("adminToken");
        localStorage.removeItem("isAdmin");
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userRole");
        localStorage.removeItem("userEmail");

        navigate("/login", {
          replace: true,
        });

        throw new Error(
          "Your session has expired. Please login again."
        );
      }

      const existingHeaders =
        options.headers || {};

      const response = await fetch(url, {
        ...options,

        headers: {
          ...existingHeaders,

          Authorization: `Bearer ${token}`,

          ...(options.body &&
          !existingHeaders["Content-Type"]
            ? {
                "Content-Type":
                  "application/json",
              }
            : {}),
        },
      });

      if (
        response.status === 401 ||
        response.status === 403
      ) {
        localStorage.removeItem("user");
        localStorage.removeItem("token");
        localStorage.removeItem("adminToken");
        localStorage.removeItem("isAdmin");
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userRole");
        localStorage.removeItem("userEmail");

        navigate("/login", {
          replace: true,
        });

        throw new Error(
          "Your session has expired. Please login again."
        );
      }

      return response;
    },
    [getAuthToken, navigate]
  );

  // =====================================================
  // LOAD MESSAGES
  // =====================================================

  const loadMessages = useCallback(
    async (showRefresh = false) => {
      try {
        if (showRefresh) {
          setRefreshing(true);
        } else {
          setLoading(true);
        }

        setError("");

        const response =
          await authenticatedFetch(
            `${API}/contact`
          );

        let data = {};

        try {
          data = await response.json();
        } catch {
          data = {};
        }

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Failed to load messages."
          );
        }

        const messageData =
          Array.isArray(data)
            ? data
            : data.messages ||
              data.data ||
              [];

        setMessages(
          messageData
        );
      } catch (error) {
        console.error(
          "Message fetch error:",
          error
        );

        setError(
          error.message ||
            "Unable to load contact messages."
        );
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [authenticatedFetch]
  );

  // =====================================================
  // DELETE MESSAGE
  // =====================================================

  const deleteMessage = async (id) => {
    const confirmed =
      window.confirm(
        "Are you sure you want to permanently delete this message?"
      );

    if (!confirmed) {
      return;
    }

    try {
      setDeletingId(id);
      setError("");

      const response =
        await authenticatedFetch(
          `${API}/contact/${id}`,
          {
            method: "DELETE",
          }
        );

      let data = {};

      try {
        data = await response.json();
      } catch {
        data = {};
      }

      if (!response.ok) {
        throw new Error(
          data.message ||
            "Failed to delete message."
        );
      }

      setMessages(
        (previous) =>
          previous.filter(
            (item) =>
              item._id !== id
          )
      );
    } catch (error) {
      console.error(
        "Delete message error:",
        error
      );

      setError(
        error.message ||
          "Unable to delete message."
      );
    } finally {
      setDeletingId(null);
    }
  };

  // =====================================================
  // INITIAL LOAD
  // =====================================================

  useEffect(() => {
    loadMessages();
  }, [loadMessages]);

  // =====================================================
  // SEARCH
  // =====================================================

  const filteredMessages =
    useMemo(() => {
      const value =
        search
          .trim()
          .toLowerCase();

      if (!value) {
        return messages;
      }

      return messages.filter(
        (item) =>
          [
            item.name,
            item.email,
            item.message,
          ]
            .filter(Boolean)
            .some((field) =>
              String(field)
                .toLowerCase()
                .includes(value)
            )
      );
    }, [messages, search]);

  // =====================================================
  // DATE
  // =====================================================

  const formatDate = (date) => {
    if (!date) {
      return "Date unavailable";
    }

    const parsedDate =
      new Date(date);

    if (
      Number.isNaN(
        parsedDate.getTime()
      )
    ) {
      return "Date unavailable";
    }

    return parsedDate.toLocaleString();
  };

  // =====================================================
  // PAGE
  // =====================================================

  return (
    <div className="message-admin-page">

      <section className="message-admin-hero">

        <div className="message-hero-glow message-glow-one"></div>
        <div className="message-hero-glow message-glow-two"></div>

        <div className="message-hero-inner">

          <div>

            <div className="message-eyebrow">
              <span></span>
              ADMINISTRATION
            </div>

            <h1>
              Contact Messages
            </h1>

            <p>
              Review and manage messages
              received from visitors and
              sanctuary supporters.
            </p>

          </div>

          <div className="message-hero-actions">

            <button
              type="button"
              className="message-refresh-btn"
              onClick={() =>
                loadMessages(true)
              }
              disabled={
                refreshing || loading
              }
            >
              {refreshing
                ? "Refreshing..."
                : "↻ Refresh"}
            </button>

            <Link
              to="/admin"
              className="message-dashboard-btn"
            >
              ← Dashboard
            </Link>

          </div>

        </div>

      </section>

      <main className="message-admin-content">

        <section className="message-stats">

          <div className="message-stat-card stat-orange">

            <div className="message-stat-icon">
              💬
            </div>

            <div>

              <div className="message-stat-label">
                TOTAL MESSAGES
              </div>

              <div className="message-stat-number">
                {loading
                  ? "—"
                  : messages.length}
              </div>

              <div className="message-stat-description">
                Messages received
              </div>

            </div>

          </div>

          <div className="message-stat-card stat-blue">

            <div className="message-stat-icon">
              📋
            </div>

            <div>

              <div className="message-stat-label">
                SHOWING
              </div>

              <div className="message-stat-number">
                {loading
                  ? "—"
                  : filteredMessages.length}
              </div>

              <div className="message-stat-description">
                Matching messages
              </div>

            </div>

          </div>

          <div className="message-stat-card stat-green">

            <div className="message-stat-icon">
              ✓
            </div>

            <div>

              <div className="message-stat-label">
                STATUS
              </div>

              <div className="message-stat-word">
                ACTIVE
              </div>

              <div className="message-stat-description">
                Messaging system is live
              </div>

            </div>

          </div>

        </section>

        <section className="message-toolbar">

          <div className="message-search">

            <span>⌕</span>

            <input
              type="text"
              placeholder="Search name, email or message..."
              value={search}
              onChange={(event) =>
                setSearch(
                  event.target.value
                )
              }
            />

            {search && (
              <button
                type="button"
                className="message-clear-search"
                onClick={() =>
                  setSearch("")
                }
                aria-label="Clear search"
              >
                ×
              </button>
            )}

          </div>

          <div className="message-result-count">
            {loading
              ? "Loading..."
              : `Showing ${filteredMessages.length} of ${messages.length}`}
          </div>

        </section>

        {error && (
          <div className="message-error">

            <div className="message-error-icon">
              !
            </div>

            <div>

              <strong>
                Unable to load messages
              </strong>

              <p>
                {error}
              </p>

            </div>

            <button
              type="button"
              onClick={() =>
                loadMessages()
              }
            >
              Try Again
            </button>

          </div>
        )}

        {loading && !error && (
          <div className="message-state-card">

            <div className="message-loader"></div>

            <h3>
              Loading messages...
            </h3>

            <p>
              Please wait while we fetch
              the latest contact messages.
            </p>

          </div>
        )}

        {!loading &&
          !error &&
          filteredMessages.length === 0 && (

            <div className="message-state-card empty">

              <div className="message-empty-icon">
                {search ? "⌕" : "💬"}
              </div>

              <h3>
                {search
                  ? "No matching messages"
                  : "No messages yet"}
              </h3>

              <p>
                {search
                  ? "Try changing your search term."
                  : "Messages submitted through the contact form will appear here."}
              </p>

              {search && (
                <button
                  type="button"
                  className="message-reset-btn"
                  onClick={() =>
                    setSearch("")
                  }
                >
                  Clear Search
                </button>
              )}

            </div>
          )}

        {!loading &&
          !error &&
          filteredMessages.length > 0 && (

            <section className="message-list-section">

              <div className="message-list-heading">

                <div>

                  <div className="message-section-label">
                    INBOX MANAGEMENT
                  </div>

                  <h2>
                    Received Messages
                  </h2>

                  <p>
                    Review visitor enquiries
                    and messages sent to your
                    sanctuary.
                  </p>

                </div>

              </div>

              <div className="message-list">

                {filteredMessages.map(
                  (item) => {

                    const isDeleting =
                      deletingId ===
                      item._id;

                    return (
                      <article
                        className="message-card"
                        key={item._id}
                      >

                        <div className="message-card-top">

                          <div className="message-person">

                            <div className="message-avatar">
                              {item.name
                                ? item.name
                                    .charAt(0)
                                    .toUpperCase()
                                : "V"}
                            </div>

                            <div>

                              <div className="message-person-label">
                                VISITOR
                              </div>

                              <h3>
                                {item.name ||
                                  "Unknown Visitor"}
                              </h3>

                              <div className="message-id">
                                ID:{" "}
                                {item._id ||
                                  "N/A"}
                              </div>

                            </div>

                          </div>

                          <span className="message-status">
                            <span></span>
                            Received
                          </span>

                        </div>

                        <div className="message-details">

                          <div className="message-detail">

                            <div className="message-detail-icon">
                              ✉
                            </div>

                            <div>

                              <span>
                                EMAIL
                              </span>

                              <strong>
                                {item.email ||
                                  "Not provided"}
                              </strong>

                            </div>

                          </div>

                          <div className="message-detail">

                            <div className="message-detail-icon">
                              ◷
                            </div>

                            <div>

                              <span>
                                RECEIVED
                              </span>

                              <strong>
                                {formatDate(
                                  item.createdAt
                                )}
                              </strong>

                            </div>

                          </div>

                        </div>

                        <div className="message-body">

                          <div className="message-body-heading">

                            <span>
                              💬
                            </span>

                            <strong>
                              Visitor Message
                            </strong>

                          </div>

                          <p>
                            {item.message ||
                              "No message content provided."}
                          </p>

                        </div>

                        <div className="message-card-footer">

                          <div className="message-current-status">

                            <span></span>

                            Message received
                          </div>

                          <button
                            type="button"
                            className="message-delete-btn"
                            onClick={() =>
                              deleteMessage(
                                item._id
                              )
                            }
                            disabled={
                              isDeleting
                            }
                          >
                            {isDeleting
                              ? "Deleting..."
                              : "× Delete Message"}
                          </button>

                        </div>

                      </article>
                    );
                  }
                )}

              </div>

            </section>
          )}

      </main>

    </div>
  );
}

export default Message;
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import "./signup.css";

function Signup() {
  const navigate = useNavigate();

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const signup = async (e) => {
    e.preventDefault();

    setError("");
    setLoading(true);

    const form = new FormData(e.target);

    const data = {
      name: form.get("name"),
      email: form.get("email"),
      password: form.get("password"),
    };

    try {
      const response = await fetch(
        "http://localhost:5000/api/auth/signup",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        setError(
          result.message || "Unable to create your account."
        );
        return;
      }

      navigate("/login", {
        replace: true,
      });
    } catch (error) {
      console.error("Signup error:", error);

      setError(
        "Unable to connect to server. Please make sure backend is running."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="signup-page">

      {/* Background decorations */}
      <div className="signup-orb signup-orb-one"></div>
      <div className="signup-orb signup-orb-two"></div>

      <div className="signup-wrapper">

        {/* LEFT BRAND PANEL */}
        <div className="signup-brand-panel">

          <div className="signup-brand-logo">
            <img
              src="/logo.jpeg"
              alt="Dog Canine Sanctuary"
            />
          </div>

          <div className="signup-brand-name">
            DOG CANINE
          </div>

          <div className="signup-brand-subtitle">
            SANCTUARY
          </div>

          <div className="signup-divider"></div>

          <h1>
            Give a Dog
            <br />
            <span>A Second Chance.</span>
          </h1>

          <p>
            Become part of a caring community helping
            rescued dogs find safety, love and forever
            families.
          </p>

          <div className="signup-stats">

            <div>
              <strong>350+</strong>
              <span>Dogs Rescued</span>
            </div>

            <div>
              <strong>120+</strong>
              <span>Happy Adoptions</span>
            </div>

            <div>
              <strong>24/7</strong>
              <span>Care & Support</span>
            </div>

          </div>

        </div>

        {/* RIGHT SIGNUP PANEL */}
        <div className="signup-form-panel">

          <div className="signup-top-icon">
            🐾
          </div>

          <div className="signup-eyebrow">
            JOIN OUR COMMUNITY
          </div>

          <h2>
            Create Your
            <span> Account</span>
          </h2>

          <p className="signup-description">
            Start your journey with Dog Canine Sanctuary.
          </p>

          {/* ERROR */}
          {error && (
            <div className="signup-error">

              <div className="signup-error-icon">
                !
              </div>

              <div>
                <strong>Signup failed</strong>
                <p>{error}</p>
              </div>

            </div>
          )}

          <form
            className="signup-form"
            onSubmit={signup}
          >

            {/* NAME */}
            <div className="signup-field">

              <label htmlFor="signup-name">
                Full Name
              </label>

              <div className="signup-input">
                <span>👤</span>

                <input
                  id="signup-name"
                  name="name"
                  type="text"
                  placeholder="Enter your full name"
                  autoComplete="name"
                  required
                />
              </div>

            </div>

            {/* EMAIL */}
            <div className="signup-field">

              <label htmlFor="signup-email">
                Email Address
              </label>

              <div className="signup-input">
                <span>✉️</span>

                <input
                  id="signup-email"
                  name="email"
                  type="email"
                  placeholder="Enter your email"
                  autoComplete="email"
                  required
                />
              </div>

            </div>

            {/* PASSWORD */}
            <div className="signup-field">

              <label htmlFor="signup-password">
                Password
              </label>

              <div className="signup-input">
                <span>🔒</span>

                <input
                  id="signup-password"
                  name="password"
                  type="password"
                  placeholder="Create a password"
                  autoComplete="new-password"
                  required
                />
              </div>

            </div>

            {/* TERMS */}
            <label className="signup-terms">
              <input
                type="checkbox"
                required
              />

              <span>
                I agree to join the Dog Canine Sanctuary
                community.
              </span>
            </label>

            {/* BUTTON */}
            <button
              type="submit"
              className="signup-submit"
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="signup-spinner"></span>
                  Creating Account...
                </>
              ) : (
                <>
                  Create Account
                  <span>→</span>
                </>
              )}
            </button>

          </form>

          {/* LOGIN LINK */}
          <div className="signup-login-link">
            <span>
              Already have an account?
            </span>

            <Link to="/login">
              Login →
            </Link>
          </div>

          <div className="signup-security">
            🔐 Your information is securely protected
          </div>

        </div>

      </div>

    </section>
  );
}

export default Signup;
import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./login.css";

const API_URL =
  process.env.REACT_APP_API_URL || "http://localhost:5000";

function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();

    setError("");

    const cleanEmail = email.trim().toLowerCase();

    if (!cleanEmail || !password.trim()) {
      setError("Please enter your email and password.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch(
        `${API_URL}/api/auth/login`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email: cleanEmail,
            password,
          }),
        }
      );

      const data = await response.json();

      console.log("LOGIN RESPONSE:", data);

      if (!response.ok || !data.success) {
        setError(
          data.message ||
            "Invalid email or password."
        );

        setLoading(false);
        return;
      }

      /*
        ================================================
        BACKEND LOGIN SUCCESS
        ================================================
      */

      const token = data.token;
      const user = data.user;

      if (!token || !user) {
        setError(
          "Login successful but authentication data is missing."
        );

        setLoading(false);
        return;
      }

      const isAdmin =
        String(user.role).toLowerCase() === "admin";

      /*
        ================================================
        CLEAR OLD SESSION
        ================================================
      */

      localStorage.removeItem("token");
      localStorage.removeItem("adminToken");
      localStorage.removeItem("user");
      localStorage.removeItem("userEmail");
      localStorage.removeItem("userRole");
      localStorage.removeItem("isAdmin");
      localStorage.removeItem("isLoggedIn");

      /*
        ================================================
        SAVE NEW SESSION
        ================================================
      */

      localStorage.setItem(
        "token",
        token
      );

      localStorage.setItem(
        "isLoggedIn",
        "true"
      );

      localStorage.setItem(
        "userEmail",
        user.email
      );

      localStorage.setItem(
        "userRole",
        isAdmin ? "admin" : "user"
      );

      localStorage.setItem(
        "isAdmin",
        isAdmin ? "true" : "false"
      );

      localStorage.setItem(
        "user",
        JSON.stringify({
          id: user.id,
          name: user.name,
          email: user.email,
          role: user.role,
          userRole: isAdmin
            ? "admin"
            : "user",
          isAdmin,
        })
      );

      console.log(
        "LOGIN SUCCESS:",
        {
          email: user.email,
          role: user.role,
          isAdmin,
          tokenExists: !!token,
        }
      );

      /*
        ================================================
        REDIRECT
        ================================================
      */

      if (isAdmin) {
        navigate("/admin", {
          replace: true,
        });
      } else {
        navigate("/", {
          replace: true,
        });
      }
    } catch (error) {
      console.error(
        "Login request error:",
        error
      );

      setError(
        "Unable to connect to server. Please make sure backend is running."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page">

      {/* LEFT SIDE */}

      <div className="auth-image-side">

        <div className="auth-image-overlay">

          <Link
            to="/"
            className="auth-logo"
          >
            <img
              src="/logo.jpeg"
              alt="Dog Canine Sanctuary"
            />

            <div>
              <strong>
                Dog Canine
              </strong>

              <span>
                Sanctuary
              </span>
            </div>
          </Link>

          <div className="auth-message">

            <span>
              🐾 Welcome Back
            </span>

            <h1>
              Give Every Dog
              <strong>
                A Second Chance.
              </strong>
            </h1>

            <p>
              Together, we can rescue,
              care for and find loving
              forever homes for dogs who
              need them most.
            </p>

          </div>

        </div>

      </div>

      {/* RIGHT SIDE */}

      <div className="auth-form-side">

        <div className="auth-card">

          <div className="auth-card-header">

            <span className="auth-small-title">
              WELCOME BACK
            </span>

            <h2>
              Login to your account
            </h2>

            <p>
              Continue your journey with
              Dog Canine Sanctuary.
            </p>

          </div>

          {/* ERROR */}

          {error && (
            <div className="auth-error">
              <strong>
                Login failed
              </strong>

              <span>
                {error}
              </span>
            </div>
          )}

          <form onSubmit={handleLogin}>

            {/* EMAIL */}

            <div className="form-group">

              <label>
                Email Address
              </label>

              <div className="input-wrapper">

                <span>
                  ✉️
                </span>

                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) =>
                    setEmail(e.target.value)
                  }
                  autoComplete="email"
                  disabled={loading}
                />

              </div>

            </div>

            {/* PASSWORD */}

            <div className="form-group">

              <div className="password-label-row">

                <label>
                  Password
                </label>

                <Link
                  to="/forgot-password"
                >
                  Forgot Password?
                </Link>

              </div>

              <div className="input-wrapper">

                <span>
                  🔒
                </span>

                <input
                  type={
                    showPassword
                      ? "text"
                      : "password"
                  }
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) =>
                    setPassword(e.target.value)
                  }
                  autoComplete="current-password"
                  disabled={loading}
                />

                <button
                  type="button"
                  className="show-password"
                  onClick={() =>
                    setShowPassword(
                      !showPassword
                    )
                  }
                  aria-label={
                    showPassword
                      ? "Hide password"
                      : "Show password"
                  }
                >
                  {showPassword
                    ? "🙈"
                    : "👁️"}
                </button>

              </div>

            </div>

            {/* REMEMBER */}

            <label className="remember-row">

              <input
                type="checkbox"
              />

              <span>
                Remember me
              </span>

            </label>

            {/* LOGIN */}

            <button
              type="submit"
              className="auth-submit-btn"
              disabled={loading}
            >
              {loading
                ? "Logging in..."
                : "Login to Account"}

              <span>
                →
              </span>
            </button>

          </form>

          <div className="auth-bottom">

            <span>
              Don't have an account?
            </span>

            <Link to="/signup">
              Create Account
            </Link>

          </div>

          <Link
            to="/"
            className="back-home"
          >
            ← Back to Home
          </Link>

        </div>

      </div>

    </div>
  );
}

export default Login;
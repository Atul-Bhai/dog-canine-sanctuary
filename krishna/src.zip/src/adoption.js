import { useState } from "react";
import "./adoption.css";

function Adoption() {
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submitForm = async (e) => {
    e.preventDefault();

    setSubmitted(false);
    setError("");
    setLoading(true);

    const form = new FormData(e.target);

    const data = {
      name: String(form.get("name") || "").trim(),
      email: String(form.get("email") || "").trim(),
      phone: String(form.get("phone") || "").trim(),
      dog: String(form.get("dog") || "").trim(),
      message: String(form.get("message") || "").trim(),
    };

    try {
      const response = await fetch(
        "http://localhost:5000/api/adoption",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        throw new Error(
          result.message ||
            "Unable to submit your adoption application."
        );
      }

      setSubmitted(true);
      e.target.reset();
    } catch (error) {
      console.error("Adoption error:", error);

      setError(
        error.message ||
          "Unable to connect to the sanctuary server."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="adoption-page">
      <div className="adoption-container">

        <div className="adoption-header">
          <div className="adoption-icon">🐾</div>

          <div className="adoption-eyebrow">
            GIVE LOVE • SAVE A LIFE
          </div>

          <h1>Adopt a Dog</h1>

          <p>
            Every rescued dog deserves a safe,
            loving and permanent home. Start your
            adoption journey today.
          </p>
        </div>

        <div className="adoption-card">

          <div className="adoption-card-header">
            <div>
              <span>ADOPTION APPLICATION</span>

              <h2>Tell us about yourself</h2>

              <p>
                Fill in the details below and our
                sanctuary team will review your
                application.
              </p>
            </div>

            <div className="adoption-step">
              <strong>01</strong>
              <span>APPLICATION</span>
            </div>
          </div>

          {submitted && (
            <div className="adoption-success">
              <div className="adoption-success-icon">
                ✓
              </div>

              <div>
                <strong>
                  Application submitted successfully!
                </strong>

                <p>
                  Thank you for choosing to give a
                  rescued dog a forever home. Our
                  sanctuary team will review your
                  application and contact you soon.
                </p>
              </div>
            </div>
          )}

          {error && (
            <div className="adoption-error">
              <div className="adoption-error-icon">
                !
              </div>

              <div>
                <strong>
                  We couldn't submit your application.
                </strong>

                <p>{error}</p>
              </div>
            </div>
          )}

          <form onSubmit={submitForm}>

            <div className="adoption-section-title">
              <span className="adoption-section-number">
                01
              </span>

              <div>
                <h3>Your Information</h3>

                <p>
                  Please provide your basic contact
                  details.
                </p>
              </div>
            </div>

            <div className="adoption-form-grid">

              <div className="adoption-field">
                <label htmlFor="adoption-name">
                  Full Name <span>*</span>
                </label>

                <input
                  id="adoption-name"
                  type="text"
                  name="name"
                  placeholder="Enter your full name"
                  autoComplete="name"
                  required
                />
              </div>

              <div className="adoption-field">
                <label htmlFor="adoption-email">
                  Email Address <span>*</span>
                </label>

                <input
                  id="adoption-email"
                  type="email"
                  name="email"
                  placeholder="you@example.com"
                  autoComplete="email"
                  required
                />
              </div>

              <div className="adoption-field">
                <label htmlFor="adoption-phone">
                  Phone Number <span>*</span>
                </label>

                <input
                  id="adoption-phone"
                  type="tel"
                  name="phone"
                  placeholder="Enter your phone number"
                  autoComplete="tel"
                  required
                />
              </div>

            </div>

            <div className="adoption-section-title">
              <span className="adoption-section-number">
                02
              </span>

              <div>
                <h3>Choose Your Companion</h3>

                <p>
                  Which rescued dog would you like
                  to welcome into your family?
                </p>
              </div>
            </div>

            <div className="adoption-dog-selection">

              <div className="adoption-field">
                <label htmlFor="adoption-dog">
                  Dog You Want to Adopt <span>*</span>
                </label>

                <select
                  id="adoption-dog"
                  name="dog"
                  required
                  defaultValue=""
                >
                  <option value="" disabled>
                    Select a dog
                  </option>

                  <option value="Bruno">Bruno</option>
                  <option value="Bella">Bella</option>
                  <option value="Rocky">Rocky</option>
                  <option value="Max">Max</option>
                  <option value="Daisy">Daisy</option>
                </select>
              </div>

              <div className="adoption-dog-note">
                <span>🐶</span>

                <p>
                  Don't worry if you're not sure.
                  Our team can help you find a dog
                  that matches your lifestyle.
                </p>
              </div>

            </div>

            <div className="adoption-section-title">
              <span className="adoption-section-number">
                03
              </span>

              <div>
                <h3>About You</h3>

                <p>
                  Tell us anything that may help us
                  understand your adoption plans.
                </p>
              </div>
            </div>

            <div className="adoption-field adoption-message-field">
              <label htmlFor="adoption-message">
                Your Message
              </label>

              <textarea
                id="adoption-message"
                name="message"
                rows="6"
                placeholder="Tell us about yourself, your home, experience with dogs, or anything else you'd like our team to know..."
              />

              <small>
                This information helps our team
                understand your adoption plans.
              </small>
            </div>

            <div className="adoption-submit-area">

              <div className="adoption-privacy">
                <span>🔒</span>

                <p>
                  Your information is used only to
                  process your adoption application.
                </p>
              </div>

              <button
                type="submit"
                className="adoption-submit-btn"
                disabled={loading}
              >
                {loading ? (
                  <>
                    <span className="adoption-spinner"></span>
                    Submitting Application...
                  </>
                ) : (
                  <>
                    Submit Application
                    <span>→</span>
                  </>
                )}
              </button>

            </div>

          </form>
        </div>

        <div className="adoption-bottom-note">
          <span>❤️</span>

          <p>
            Thank you for opening your heart to a
            rescued dog. Together, we can give them
            the second chance they deserve.
          </p>
        </div>

      </div>
    </section>
  );
}

export default Adoption;
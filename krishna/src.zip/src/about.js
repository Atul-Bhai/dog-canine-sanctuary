import React from "react";
import "./about.css";

function About() {
  return (
    <main className="about-page">

      {/* ================= HERO ================= */}
      <section className="about-hero">

        <div className="about-hero-paw paw-one">🐾</div>
        <div className="about-hero-paw paw-two">🐾</div>

        <div className="about-container about-hero-content">

          <span className="about-eyebrow">
            🐾 OUR STORY
          </span>

          <h1>
            About Our <span>Sanctuary</span>
          </h1>

          <p>
            Where every rescued dog gets another chance at a
            happy, healthy and loving life.
          </p>

          <div className="about-divider"></div>

        </div>

      </section>


      {/* ================= MISSION ================= */}
      <section className="about-mission">

        <div className="about-container mission-grid">

          {/* LEFT */}
          <div className="mission-content">

            <span className="section-label">
              OUR MISSION
            </span>

            <h2>
              Every Dog Deserves
              <span> Love.</span> ❤️
            </h2>

            <p>
              Dog Canine Sanctuary is dedicated to rescuing abandoned,
              injured and homeless dogs and giving them a safe place
              to recover.
            </p>

            <p>
              Our team provides nutritious food, medical treatment,
              comfortable shelter, grooming and emotional care to help
              every dog feel safe again.
            </p>

            <p>
              We also work with loving and responsible families to find
              safe, permanent homes for our rescued dogs.
            </p>


            {/* MISSION POINTS */}
            <div className="mission-points">

              <div className="mission-point">
                <div className="mission-icon orange">
                  🏠
                </div>

                <div>
                  <h3>Safe Shelter</h3>
                  <p>
                    A safe and comfortable place for rescued dogs.
                  </p>
                </div>
              </div>


              <div className="mission-point">
                <div className="mission-icon red">
                  ❤️
                </div>

                <div>
                  <h3>Medical & Emotional Care</h3>
                  <p>
                    Complete care to help every dog heal and recover.
                  </p>
                </div>
              </div>


              <div className="mission-point">
                <div className="mission-icon green">
                  🐾
                </div>

                <div>
                  <h3>Loving Forever Homes</h3>
                  <p>
                    Helping dogs find responsible forever families.
                  </p>
                </div>
              </div>

            </div>

          </div>


          {/* RIGHT FEATURE */}
          <div className="mission-visual">

            <div className="mission-card">

              <div className="mission-card-glow"></div>

              <div className="dog-circle">
                🐕
              </div>

              <span className="mission-card-label">
                DOG CANINE SANCTUARY
              </span>

              <h3>
                Love • Care • Rescue
              </h3>

              <p>
                Every dog deserves safety, kindness and a loving home.
                Together, we can give them the second chance they deserve.
              </p>


              <div className="mission-tags">

                <span>Rescue</span>
                <span>Rehabilitate</span>
                <span>Rehome</span>

              </div>

            </div>


            <div className="floating-card floating-card-one">
              ❤️
              <div>
                <strong>Give Love</strong>
                <small>Every single day</small>
              </div>
            </div>


            <div className="floating-card floating-card-two">
              🐾
              <div>
                <strong>Save Lives</strong>
                <small>One dog at a time</small>
              </div>
            </div>

          </div>

        </div>

      </section>


      {/* ================= VALUES ================= */}
      <section className="about-values">

        <div className="about-container">

          <div className="values-heading">

            <span className="section-label">
              OUR VALUES
            </span>

            <h2>
              What We <span>Believe</span>
            </h2>

            <p>
              Our sanctuary is built around compassion, responsibility
              and giving every dog a chance.
            </p>

          </div>


          <div className="values-grid">

            {/* CARD 1 */}
            <article className="value-card">

              <div className="value-icon orange-icon">
                🐾
              </div>

              <span className="value-number">
                01
              </span>

              <h3>
                Compassion
              </h3>

              <p>
                Every dog is treated with patience, kindness and respect.
                We believe every animal deserves to feel safe and loved.
              </p>

            </article>


            {/* CARD 2 */}
            <article className="value-card">

              <div className="value-icon red-icon">
                ❤️
              </div>

              <span className="value-number">
                02
              </span>

              <h3>
                Responsible Care
              </h3>

              <p>
                We provide the medical, emotional and daily care every
                rescued dog needs throughout their journey.
              </p>

            </article>


            {/* CARD 3 */}
            <article className="value-card">

              <div className="value-icon green-icon">
                🏡
              </div>

              <span className="value-number">
                03
              </span>

              <h3>
                Forever Homes
              </h3>

              <p>
                We help rescued dogs find safe, loving and permanent
                families where they can live happily.
              </p>

            </article>

          </div>

        </div>

      </section>


      {/* ================= CTA ================= */}
      <section className="about-cta">

        <div className="about-container">

          <div className="cta-box">

            <div className="cta-paws">
              🐾
            </div>

            <div className="cta-content">

              <span>
                HELP US MAKE A DIFFERENCE
              </span>

              <h2>
                Every Paw Deserves
                <br />
                <strong>A Second Chance.</strong>
              </h2>

              <p>
                Whether you adopt, volunteer, donate or simply share
                our mission, you can help change a dog's life.
              </p>

            </div>

            <div className="cta-actions">

              <a href="/adoption" className="cta-primary">
                Adopt a Dog →
              </a>

              <a href="/volunteer" className="cta-secondary">
                Become a Volunteer
              </a>

            </div>

          </div>

        </div>

      </section>

    </main>
  );
}

export default About;
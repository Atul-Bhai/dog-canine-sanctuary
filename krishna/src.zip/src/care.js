import React from "react";
import "./care.css";

function Care() {
  const services = [
    {
      icon: "🍖",
      number: "01",
      title: "Food & Nutrition",
      description:
        "Balanced and nutritious meals prepared to keep every rescued dog strong, healthy and energetic.",
    },
    {
      icon: "💉",
      number: "02",
      title: "Vaccination",
      description:
        "Preventive healthcare and regular vaccinations help protect our dogs from serious illnesses.",
    },
    {
      icon: "🩺",
      number: "03",
      title: "Medical Care",
      description:
        "Sick and injured dogs receive proper medical attention, treatment and recovery support.",
    },
    {
      icon: "🛁",
      number: "04",
      title: "Grooming",
      description:
        "Regular bathing, cleaning, grooming and hygiene keep every dog comfortable and fresh.",
    },
    {
      icon: "🏃",
      number: "05",
      title: "Exercise",
      description:
        "Daily movement, walks and playful activities help our dogs stay active and mentally healthy.",
    },
    {
      icon: "❤️",
      number: "06",
      title: "Emotional Care",
      description:
        "Love, patience, attention and companionship help rescued dogs rebuild trust and confidence.",
    },
  ];

  const values = [
    {
      icon: "🏠",
      title: "Safe Environment",
      text: "Clean, peaceful and secure surroundings where every dog can recover comfortably.",
    },
    {
      icon: "👩‍⚕️",
      title: "Health First",
      text: "Regular observation, preventive care and medical support whenever it is needed.",
    },
    {
      icon: "🤗",
      title: "Lots of Love",
      text: "Every dog receives patience, affection and positive human interaction every day.",
    },
  ];

  return (
    <main className="care-page">

      {/* =====================================================
          HERO
      ===================================================== */}

      <section className="care-hero">

        <div className="care-glow care-glow-one"></div>
        <div className="care-glow care-glow-two"></div>

        <div className="care-hero-container">

          <div className="care-hero-content">

            <div className="care-eyebrow">
              <span className="care-eyebrow-dot"></span>
              PREMIUM DOG CARE
            </div>

            <h1>
              Care That Feels
              <span> Like Home.</span>
            </h1>

            <p>
              Every rescued dog deserves more than shelter.
              They deserve nutritious food, medical attention,
              exercise, comfort and unconditional love.
            </p>

            <div className="care-hero-actions">
              <a href="#care-services" className="care-primary-btn">
                Explore Our Care
                <span>↓</span>
              </a>

              <div className="care-mini-stat">
                <strong>24/7</strong>
                <span>Compassionate Care</span>
              </div>
            </div>

          </div>


          {/* 3D VISUAL */}

          <div className="care-hero-visual">

            <div className="care-orbit orbit-one"></div>
            <div className="care-orbit orbit-two"></div>

            <div className="care-3d-card">

              <div className="care-card-glow"></div>

              <div className="care-floating-badge badge-top">
                <span>♥</span>
                Loved
              </div>

              <div className="care-dog-sphere">

                <div className="care-sphere-ring"></div>

                <div className="care-dog">
                  🐕
                </div>

              </div>

              <div className="care-visual-title">
                Happy.
                <span>Healthy.</span>
                Loved.
              </div>

              <div className="care-visual-bottom">
                <span>🐾</span>
                <span>Every dog matters.</span>
              </div>

            </div>

          </div>

        </div>

      </section>


      {/* =====================================================
          INTRO
      ===================================================== */}

      <section className="care-intro">

        <div className="care-container">

          <div className="care-intro-grid">

            <div>

              <span className="care-section-label">
                OUR APPROACH
              </span>

              <h2>
                Complete care for
                <span> every stage of recovery.</span>
              </h2>

            </div>

            <div className="care-intro-text">

              <p>
                Rescue is only the beginning. Our goal is to
                create an environment where every dog can heal,
                regain confidence and experience the happiness
                they deserve.
              </p>

            </div>

          </div>

        </div>

      </section>


      {/* =====================================================
          SERVICES
      ===================================================== */}

      <section
        className="care-services"
        id="care-services"
      >

        <div className="care-container">

          <div className="care-section-heading">

            <span className="care-section-label">
              WHAT WE PROVIDE
            </span>

            <h2>
              Care built around
              <span> their needs.</span>
            </h2>

            <p>
              From everyday essentials to emotional recovery,
              our care program focuses on the whole dog.
            </p>

          </div>


          <div className="care-services-grid">

            {services.map((service) => (

              <article
                className="care-service-card"
                key={service.number}
              >

                <div className="care-card-number">
                  {service.number}
                </div>

                <div className="care-service-icon">
                  <div className="care-icon-inner">
                    {service.icon}
                  </div>
                </div>

                <div className="care-service-content">

                  <h3>
                    {service.title}
                  </h3>

                  <p>
                    {service.description}
                  </p>

                  <div className="care-card-link">
                    Essential Care
                    <span>→</span>
                  </div>

                </div>

              </article>

            ))}

          </div>

        </div>

      </section>


      {/* =====================================================
          FEATURE
      ===================================================== */}

      <section className="care-feature">

        <div className="care-container">

          <div className="care-feature-card">

            <div className="care-feature-glow"></div>

            <div className="care-feature-content">

              <span className="care-feature-label">
                MORE THAN A SHELTER
              </span>

              <h2>
                A second chance
                <span> starts with care.</span>
              </h2>

              <p>
                A rescued dog may arrive scared, injured or
                uncertain. With patience and consistent care,
                they can learn to trust again and begin a new
                chapter of their life.
              </p>

              <div className="care-feature-points">

                <div>
                  <span>✓</span>
                  Daily nutrition
                </div>

                <div>
                  <span>✓</span>
                  Health monitoring
                </div>

                <div>
                  <span>✓</span>
                  Exercise & play
                </div>

                <div>
                  <span>✓</span>
                  Emotional support
                </div>

              </div>

            </div>


            <div className="care-feature-visual">

              <div className="care-heart-orbit"></div>

              <div className="care-heart-circle">
                ❤️
              </div>

              <div className="care-floating-chip chip-one">
                🩺 Health
              </div>

              <div className="care-floating-chip chip-two">
                🐾 Happiness
              </div>

              <div className="care-floating-chip chip-three">
                🏡 Home
              </div>

            </div>

          </div>

        </div>

      </section>


      {/* =====================================================
          VALUES
      ===================================================== */}

      <section className="care-values">

        <div className="care-container">

          <div className="care-section-heading">

            <span className="care-section-label">
              OUR PROMISE
            </span>

            <h2>
              The little things
              <span> make a big difference.</span>
            </h2>

          </div>


          <div className="care-values-grid">

            {values.map((value, index) => (

              <article
                className="care-value-card"
                key={value.title}
              >

                <div className="care-value-index">
                  0{index + 1}
                </div>

                <div className="care-value-icon">
                  {value.icon}
                </div>

                <h3>
                  {value.title}
                </h3>

                <p>
                  {value.text}
                </p>

              </article>

            ))}

          </div>

        </div>

      </section>


      {/* =====================================================
          FINAL CTA
      ===================================================== */}

      <section className="care-cta">

        <div className="care-cta-orb"></div>

        <div className="care-container">

          <div className="care-cta-content">

            <div className="care-cta-icon">
              🐾
            </div>

            <span className="care-section-label">
              EVERY LIFE MATTERS
            </span>

            <h2>
              Because every dog
              <span> deserves to feel loved.</span>
            </h2>

            <p>
              Your support helps us provide food, healthcare,
              shelter and the emotional care rescued dogs need.
            </p>

          </div>

        </div>

      </section>

    </main>
  );
}

export default Care;
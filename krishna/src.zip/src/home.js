import { Link } from "react-router-dom";
import DogCard from "./dogcard";
import "./home.css";

function Home() {
  return (
    <div className="home-page">

      {/* HERO */}
      <section className="home-hero">
        <div className="hero-glow hero-glow-one" />
        <div className="hero-glow hero-glow-two" />

        <div className="hero-container">

          <div className="hero-content">
            <div className="hero-badge">
              <span>🐾</span>
              Saving Lives • Creating Families
            </div>

            <h1>
              Every Dog
              <span>Deserves A Home.</span>
            </h1>

            <p className="hero-description">
              We rescue abandoned and injured dogs, provide them with
              love, medical care and a safe place to heal — until they
              find a family of their own.
            </p>

            <div className="hero-buttons">
              <Link to="/adoption" className="premium-btn primary-btn">
                <span>🐕</span>
                Adopt A Dog
                <strong>→</strong>
              </Link>

              <Link to="/donate" className="premium-btn secondary-btn">
                <span>❤️</span>
                Support Our Mission
              </Link>
            </div>

            <div className="trust-points">
              <div>
                <span>✓</span>
                <p>Trusted Sanctuary</p>
              </div>

              <div>
                <span>✓</span>
                <p>Veterinary Care</p>
              </div>

              <div>
                <span>✓</span>
                <p>Forever Homes</p>
              </div>
            </div>
          </div>

          <div className="hero-visual">
            <div className="hero-ring hero-ring-one" />
            <div className="hero-ring hero-ring-two" />

            <div className="hero-image-card">
              <img
                src="https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=1200&q=90"
                alt="Happy rescue dog"
              />

              <div className="hero-image-overlay">
                <div>
                  <small>Meet our rescue family</small>
                  <strong>Love changes everything ❤️</strong>
                </div>

                <div className="hero-paw">🐾</div>
              </div>
            </div>

            <div className="floating-card floating-card-top">
              <span>❤️</span>
              <div>
                <strong>500+</strong>
                <small>Lives rescued</small>
              </div>
            </div>

            <div className="floating-card floating-card-bottom">
              <span>🏠</span>
              <div>
                <strong>350+</strong>
                <small>Forever homes</small>
              </div>
            </div>
          </div>

        </div>
      </section>


      {/* STATS */}
      <section className="stats-wrapper">
        <div className="stats-card">

          <div className="stat-item">
            <span>🐕</span>
            <strong>500+</strong>
            <p>Dogs Rescued</p>
          </div>

          <div className="stat-item">
            <span>🏠</span>
            <strong>350+</strong>
            <p>Happy Adoptions</p>
          </div>

          <div className="stat-item">
            <span>🤝</span>
            <strong>100+</strong>
            <p>Active Volunteers</p>
          </div>

          <div className="stat-item">
            <span>❤️</span>
            <strong>10+</strong>
            <p>Years Of Care</p>
          </div>

        </div>
      </section>


      {/* MISSION */}
      <section className="mission-section">
        <div className="section-container mission-grid">

          <div className="mission-image-wrap">
            <div className="image-decoration" />

            <img
              src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=1000&q=90"
              alt="Dogs together"
              className="mission-image"
            />

            <div className="mission-badge">
              <span>❤️</span>
              <strong>Every life matters</strong>
            </div>
          </div>

          <div className="mission-content">
            <span className="section-label">OUR MISSION</span>

            <h2>
              A Safe Place For
              <span>Second Chances</span>
            </h2>

            <p>
              Our sanctuary is more than a shelter. It is a place where
              frightened dogs learn to trust again, injured dogs receive
              medical care and every dog gets a chance to experience love.
            </p>

            <p>
              With the support of adopters, volunteers and kind-hearted
              donors, we continue creating brighter futures for dogs
              who have been forgotten.
            </p>

            <Link to="/about" className="dark-btn">
              Discover Our Story
              <span>→</span>
            </Link>
          </div>

        </div>
      </section>


      {/* DOGS */}
      <section className="dogs-section">
        <div className="section-container">

          <div className="section-heading">
            <span className="heading-pill">
              🐾 Find Your Companion
            </span>

            <h2>
              Dogs Looking For
              <span> A Home</span>
            </h2>

            <p>
              Meet some of our wonderful dogs who are ready to become
              part of a loving forever family.
            </p>
          </div>

          <div className="dogs-grid">

            <DogCard
              name="Bruno"
              breed="Labrador"
              age="2 Years"
              image="https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=1000&q=90"
              description="Friendly, playful and full of love."
            />

            <DogCard
              name="Bella"
              breed="Golden Retriever"
              age="3 Years"
              image="https://images.unsplash.com/photo-1558788353-f76d92427f16?auto=format&fit=crop&w=1000&q=90"
              description="Gentle and perfect for a loving family."
            />

            <DogCard
              name="Rocky"
              breed="Indie"
              age="1 Year"
              image="https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?auto=format&fit=crop&w=1000&q=90"
              description="Energetic, smart and very affectionate."
            />

          </div>

          <div className="center-button">
            <Link to="/adoption" className="outline-btn">
              View Adoption Options
              <span>→</span>
            </Link>
          </div>

        </div>
      </section>


      {/* CTA */}
      <section className="home-cta">
        <div className="cta-circle cta-circle-one" />
        <div className="cta-circle cta-circle-two" />

        <div className="cta-content">
          <div className="cta-icon">🐶❤️</div>

          <span className="section-label light-label">
            MAKE A DIFFERENCE
          </span>

          <h2>You Can Change A Dog's Life</h2>

          <p>
            One adoption, one donation or one hour of your time can
            make a life-changing difference.
          </p>

          <div className="cta-buttons">
            <Link to="/volunteer" className="cta-white-btn">
              🤝 Become A Volunteer
            </Link>

            <Link to="/donate" className="cta-outline-btn">
              ❤️ Donate Today
            </Link>
          </div>
        </div>
      </section>


      {/* FINAL MESSAGE */}
      <section className="final-message">
        <div>
          <h3>Together, we can give them a second chance.</h3>
          <p>Thank you for standing with our rescue dogs.</p>
        </div>

        <Link to="/contact">
          Contact Us →
        </Link>
      </section>

    </div>
  );
}

export default Home;
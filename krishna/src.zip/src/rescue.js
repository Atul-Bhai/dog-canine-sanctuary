import DogCard from "./dogcard";
import "./rescue.css";

function Rescue() {
  const rescueDogs = [
    {
      name: "Max",
      breed: "Indie",
      age: "2 Years",
      image:
        "https://images.unsplash.com/photo-1583337130417-3346a1be7dee?auto=format&fit=crop&w=1000&q=90",
      description:
        "Rescued from the streets and recovering beautifully."
    },
    {
      name: "Daisy",
      breed: "Beagle",
      age: "3 Years",
      image:
        "https://images.unsplash.com/photo-1507146426996-ef05306b995a?auto=format&fit=crop&w=1000&q=90",
      description:
        "A sweet dog waiting for a peaceful and loving home."
    },
    {
      name: "Charlie",
      breed: "Mixed Breed",
      age: "1 Year",
      image:
        "https://images.unsplash.com/photo-1543466835-00a7907e9de1?auto=format&fit=crop&w=1000&q=90",
      description:
        "Young, playful and ready to meet his forever family."
    }
  ];

  const rescueSteps = [
    {
      number: "01",
      icon: "🚑",
      title: "Rescue",
      text: "We respond to dogs who are abandoned, injured or in need of immediate protection."
    },
    {
      number: "02",
      icon: "🩺",
      title: "Recover",
      text: "Every rescued dog receives medical attention, nutritious food, shelter and emotional care."
    },
    {
      number: "03",
      icon: "❤️",
      title: "Rebuild",
      text: "With patience, kindness and daily companionship, dogs regain confidence and trust."
    },
    {
      number: "04",
      icon: "🏡",
      title: "Rehome",
      text: "When ready, we help each dog find a safe, responsible and loving forever home."
    }
  ];

  return (
    <main className="rescue-page">

      {/* =====================================================
          HERO
      ===================================================== */}

      <section className="rescue-hero">

        <div className="rescue-glow rescue-glow-one"></div>
        <div className="rescue-glow rescue-glow-two"></div>

        <div className="rescue-hero-inner">

          <div className="rescue-hero-content">

            <div className="rescue-eyebrow">
              <span>🐾</span>
              RESCUE • RECOVER • REHOME
            </div>

            <h1>
              Every Rescue
              <span> Starts a New Life.</span>
            </h1>

            <p>
              Behind every rescued dog is a story of survival.
              We provide safety, medical care, patience and love
              until they are ready for their next chapter.
            </p>

            <div className="rescue-hero-buttons">
              <a href="#rescued-dogs" className="rescue-primary-btn">
                Meet Our Dogs
                <span>→</span>
              </a>

              <a href="#rescue-process" className="rescue-secondary-btn">
                How We Rescue
              </a>
            </div>

            <div className="rescue-hero-stats">

              <div>
                <strong>24/7</strong>
                <span>Rescue Support</span>
              </div>

              <div>
                <strong>100%</strong>
                <span>Compassion</span>
              </div>

              <div>
                <strong>∞</strong>
                <span>Second Chances</span>
              </div>

            </div>

          </div>

          {/* 3D VISUAL */}

          <div className="rescue-hero-visual">

            <div className="visual-ring ring-one"></div>
            <div className="visual-ring ring-two"></div>

            <div className="floating-card floating-card-top">
              <span>❤️</span>
              <div>
                <strong>Love</strong>
                <small>Changes everything</small>
              </div>
            </div>

            <div className="hero-dog-orb">

              <div className="orb-glow"></div>

              <div className="hero-dog-image">
                <img
                  src="https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=1000&q=90"
                  alt="Rescued dog"
                />
              </div>

              <div className="orb-badge">
                🐾
              </div>

            </div>

            <div className="floating-card floating-card-bottom">
              <span>🏡</span>
              <div>
                <strong>Forever Home</strong>
                <small>A new beginning</small>
              </div>
            </div>

          </div>

        </div>

      </section>


      {/* =====================================================
          INTRO
      ===================================================== */}

      <section className="rescue-intro">

        <div className="rescue-container">

          <div className="rescue-intro-grid">

            <div className="intro-heading">

              <span className="section-kicker">
                OUR RESCUE MISSION
              </span>

              <h2>
                From the streets
                <span> to safety.</span>
              </h2>

            </div>

            <div className="intro-text">

              <p>
                A rescue is more than bringing a dog to a shelter.
                It is the beginning of a journey where fear slowly
                becomes trust and uncertainty becomes hope.
              </p>

              <p>
                Our sanctuary gives every rescued dog the time,
                treatment and affection they need to heal.
              </p>

            </div>

          </div>

        </div>

      </section>


      {/* =====================================================
          DOGS
      ===================================================== */}

      <section id="rescued-dogs" className="rescued-dogs-section">

        <div className="rescue-container">

          <div className="section-header">

            <div>
              <span className="section-kicker">
                CURRENTLY IN OUR CARE
              </span>

              <h2>
                Meet Our Rescued Dogs
              </h2>
            </div>

            <p>
              Each one has survived something difficult.
              Now they are waiting for something beautiful.
            </p>

          </div>


          <div className="rescue-dogs-grid">

            {rescueDogs.map((dog) => (
              <div className="rescue-dog-wrapper" key={dog.name}>

                <div className="dog-glow"></div>

                <DogCard
                  name={dog.name}
                  breed={dog.breed}
                  age={dog.age}
                  image={dog.image}
                  description={dog.description}
                />

              </div>
            ))}

          </div>

        </div>

      </section>


      {/* =====================================================
          PROCESS
      ===================================================== */}

      <section id="rescue-process" className="rescue-process-section">

        <div className="rescue-container">

          <div className="section-header centered">

            <span className="section-kicker">
              OUR APPROACH
            </span>

            <h2>
              A Journey From Rescue
              <span> To Hope</span>
            </h2>

            <p>
              Every dog follows their own healing journey,
              but our commitment remains the same.
            </p>

          </div>


          <div className="rescue-timeline">

            {rescueSteps.map((step) => (

              <div className="timeline-card" key={step.number}>

                <div className="timeline-number">
                  {step.number}
                </div>

                <div className="timeline-icon">
                  {step.icon}
                </div>

                <h3>
                  {step.title}
                </h3>

                <p>
                  {step.text}
                </p>

              </div>

            ))}

          </div>

        </div>

      </section>


      {/* =====================================================
          FEATURE
      ===================================================== */}

      <section className="rescue-feature">

        <div className="feature-background-circle circle-one"></div>
        <div className="feature-background-circle circle-two"></div>

        <div className="rescue-container">

          <div className="feature-card">

            <div className="feature-content">

              <span className="section-kicker light">
                SECOND CHANCES MATTER
              </span>

              <h2>
                One rescue can
                <span> change a lifetime.</span>
              </h2>

              <p>
                A safe place today can become a forever home tomorrow.
                Every meal, every treatment and every moment of affection
                helps a rescued dog believe in people again.
              </p>

              <div className="feature-points">

                <div>
                  <span>✓</span>
                  Safe shelter
                </div>

                <div>
                  <span>✓</span>
                  Medical support
                </div>

                <div>
                  <span>✓</span>
                  Emotional healing
                </div>

              </div>

            </div>

            <div className="feature-visual">

              <div className="feature-paw">
                🐾
              </div>

              <div className="feature-heart">
                ❤️
              </div>

              <div className="feature-home">
                🏡
              </div>

            </div>

          </div>

        </div>

      </section>


      {/* =====================================================
          FINAL MESSAGE
      ===================================================== */}

      <section className="rescue-final">

        <div className="rescue-container">

          <div className="final-card">

            <div className="final-icon">
              🐶
            </div>

            <span className="section-kicker">
              THEIR FUTURE STARTS HERE
            </span>

            <h2>
              Every Dog Deserves
              <span> A Second Chance.</span>
            </h2>

            <p>
              Rescue is the first step. Love, care and a safe home
              are what complete the journey.
            </p>

            <div className="final-paw-row">
              <span>🐾</span>
              <span>❤️</span>
              <span>🐾</span>
            </div>

          </div>

        </div>

      </section>

    </main>
  );
}

export default Rescue;
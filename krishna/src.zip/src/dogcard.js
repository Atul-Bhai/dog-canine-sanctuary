function DogCard({ name, breed, age, image, description }) {
  return (
    <div className="group flex h-full flex-col overflow-hidden rounded-2xl bg-white shadow-md ring-1 ring-stone-200 transition-all duration-300 hover:-translate-y-2 hover:shadow-2xl">

      {/* Dog Image */}
      <div className="relative h-64 overflow-hidden">
        <img
          src={image}
          alt={name}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-110"
        />

        {/* Heart */}
        <button
          type="button"
          aria-label={`Favorite ${name}`}
          className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center rounded-full bg-white/90 text-xl shadow-md backdrop-blur transition hover:scale-110"
        >
          ❤️
        </button>

        {/* Available Badge */}
        <span className="absolute bottom-4 left-4 rounded-full bg-emerald-500 px-3 py-1 text-sm font-semibold text-white shadow">
          Available for Adoption
        </span>
      </div>

      {/* Card Content */}
      <div className="flex flex-1 flex-col p-6">

        <h3 className="text-2xl font-bold text-stone-900">
          {name}
        </h3>

        {/* Breed + Age */}
        <div className="mt-3 flex flex-wrap gap-2">

          <span className="rounded-full bg-amber-50 px-3 py-1 text-sm font-medium text-amber-700">
            🐕 {breed}
          </span>

          <span className="rounded-full bg-stone-100 px-3 py-1 text-sm font-medium text-stone-600">
            🎂 {age}
          </span>

        </div>

        <p className="mt-4 flex-1 leading-7 text-stone-600">
          {description}
        </p>

        {/* Button */}
        <button
          type="button"
          className="mt-6 w-full rounded-xl bg-amber-600 px-5 py-3 font-semibold text-white shadow-md transition duration-300 hover:bg-amber-700 hover:shadow-lg"
        >
          Meet {name} ❤️
        </button>

      </div>
    </div>
  );
}

export default DogCard;
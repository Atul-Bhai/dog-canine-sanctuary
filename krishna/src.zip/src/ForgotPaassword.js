import { Link } from "react-router-dom";
import { useState } from "react";
import "./ForgotPassword.css";

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();

    setMessage("");
    setError("");
    setLoading(true);

    try {
      const response = await fetch(
        "http://localhost:5000/api/auth/forgot-password",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ email }),
        }
      );

      const result = await response.json();

      if (!response.ok) {
        setError(
          result.message || "Unable to send reset instructions."
        );
        return;
      }

      setMessage(
        result.message ||
          "If this email exists, password reset instructions have been sent."
      );
    } catch (err) {
      console.error("Forgot password error:", err);

      setError(
        "Unable to connect to server. Please try again."
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="forgot-page">

      <div className="forgot-decoration forgot-decoration-one" />
      <div className="forgot-decoration forgot-decoration-two" />

      <div className="forgot-wrapper">

        {/* LEFT BRAND PANEL */}
        <div className="forgot-brand">

          <div className="forgot-logo-box">
            <img
              src="/logo.jpeg"
              alt="Dog Canine Sanctuary"
            />
          </div>

          <div className="forgot-brand-name">
            DOG CANINE
          </div>

          <div className="forgot-brand-subtitle">
            SANCTUARY
          </div>

          <div className="forgot-line" />

          <h1>
            Don't worry.
            <br />
            We've got
            <span> you.</span>
          </h1>

          <p>
            Forgot your password? We'll help you
            get back to your Dog Canine Sanctuary
            account safely.
          </p>

          <div className="forgot-brand-points">
            <div>
              <span>🐾</span>
              <strong>Safe & Secure</strong>
            </div>

            <div>
              <span>🔐</span>
              <strong>Protected Account</strong>
            </div>

            <div>
              <span>❤️</span>
              <strong>Dog-Loving Community</strong>
            </div>
          </div>

        </div>

        {/* FORM PANEL */}
        <div className="forgot-card">

          <div className="forgot-icon">
            🔑
          </div>

          <div className="forgot-eyebrow">
            ACCOUNT RECOVERY
          </div>

          <h2>
            Forgot Your
            <span>Password?</span>
          </h2>

          <p className="forgot-description">
            Enter the email address connected to your
            account and we'll send you instructions to
            create a new password.
          </p>

          {error && (
            <div className="forgot-alert forgot-alert-error">
              <span>!</span>
              <div>
                <strong>Something went wrong</strong>
                <p>{error}</p>
              </div>
            </div>
          )}

          {message && (
            <div className="forgot-alert forgot-alert-success">
              <span>✓</span>
              <div>
                <strong>Check your email</strong>
                <p>{message}</p>
              </div>
            </div>
          )}

          <form onSubmit={handleSubmit}>

            <label htmlFor="forgot-email">
              Email Address
            </label>

            <div className="forgot-input">
              <span>✉</span>

              <input
                id="forgot-email"
                type="email"
                placeholder="Enter your email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <button
              type="submit"
              disabled={loading}
            >
              {loading ? (
                <>
                  <span className="forgot-spinner" />
                  Sending...
                </>
              ) : (
                <>
                  Send Reset Link
                  <span>→</span>
                </>
              )}
            </button>

          </form>

          <div className="forgot-back">
            Remember your password?
            <Link to="/login">
              Back to Login →
            </Link>
          </div>

          <div className="forgot-security">
            🔒 Your account information is protected
          </div>

        </div>

      </div>

    </section>
  );
}

export default ForgotPassword;
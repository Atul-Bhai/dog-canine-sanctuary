import React, {
  useCallback,
  useEffect,
  useState,
} from "react";
import { Link, useNavigate } from "react-router-dom";
import "./AdminDashboard.css";

const API_URL =
  process.env.REACT_APP_API_URL || "http://localhost:5000";

function AdminDashboard() {
  const navigate = useNavigate();

  const [stats, setStats] = useState({
    adoptions: 0,
    volunteers: 0,
    messages: 0,
  });

  const [recentAdoptions, setRecentAdoptions] =
    useState([]);

  const [loading, setLoading] =
    useState(false);

  const [error, setError] =
    useState("");

  /*
    =====================================================
    LOAD DASHBOARD DATA
    =====================================================
  */

  const loadDashboardData =
    useCallback(async () => {
      const token =
        localStorage.getItem("token") ||
        localStorage.getItem("adminToken");

      if (!token) {
        navigate("/login", {
          replace: true,
        });

        return;
      }

      setLoading(true);
      setError("");

      try {
        const headers = {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        };

        const [
          adoptionResponse,
          volunteerResponse,
          messageResponse,
        ] = await Promise.all([
          fetch(
            `${API_URL}/api/adoption`,
            {
              method: "GET",
              headers,
            }
          ),

          fetch(
            `${API_URL}/api/volunteer`,
            {
              method: "GET",
              headers,
            }
          ),

          fetch(
            `${API_URL}/api/contact`,
            {
              method: "GET",
              headers,
            }
          ),
        ]);

        /*
          Token invalid / expired
        */

        if (
          adoptionResponse.status === 401 ||
          adoptionResponse.status === 403 ||
          volunteerResponse.status === 401 ||
          volunteerResponse.status === 403 ||
          messageResponse.status === 401 ||
          messageResponse.status === 403
        ) {
          localStorage.clear();

          navigate("/login", {
            replace: true,
          });

          return;
        }

        const adoptionData =
          await adoptionResponse.json();

        const volunteerData =
          await volunteerResponse.json();

        const messageData =
          await messageResponse.json();

        console.log(
          "ADOPTION DATA:",
          adoptionData
        );

        console.log(
          "VOLUNTEER DATA:",
          volunteerData
        );

        console.log(
          "MESSAGE DATA:",
          messageData
        );

        const adoptions =
          adoptionData.applications || [];

        const volunteers =
          volunteerData.applications || [];

        const messages =
          messageData.messages || [];

        setStats({
          adoptions: adoptions.length,
          volunteers: volunteers.length,
          messages: messages.length,
        });

        setRecentAdoptions(
          adoptions.slice(0, 5)
        );
      } catch (error) {
        console.error(
          "Dashboard loading error:",
          error
        );

        setError(
          "Unable to load dashboard data. Please check backend server."
        );
      } finally {
        setLoading(false);
      }
    }, [navigate]);

  /*
    =====================================================
    CHECK ADMIN SESSION
    =====================================================
  */

  useEffect(() => {
    const isLoggedIn =
      localStorage.getItem("isLoggedIn") ===
      "true";

    const userRole =
      localStorage.getItem("userRole");

    const isAdmin =
      localStorage.getItem("isAdmin") ===
      "true";

    const token =
      localStorage.getItem("token") ||
      localStorage.getItem("adminToken");

    if (
      !isLoggedIn ||
      !isAdmin ||
      userRole !== "admin" ||
      !token
    ) {
      navigate("/login", {
        replace: true,
      });

      return;
    }

    loadDashboardData();
  }, [
    navigate,
    loadDashboardData,
  ]);

  /*
    =====================================================
    LOGOUT
    =====================================================
  */

  const handleLogout = () => {
    localStorage.removeItem(
      "isLoggedIn"
    );

    localStorage.removeItem(
      "userEmail"
    );

    localStorage.removeItem(
      "userRole"
    );

    localStorage.removeItem(
      "isAdmin"
    );

    localStorage.removeItem(
      "user"
    );

    localStorage.removeItem(
      "token"
    );

    localStorage.removeItem(
      "adminToken"
    );

    navigate("/login", {
      replace: true,
    });
  };

  /*
    =====================================================
    FORMAT DATE
    =====================================================
  */

  const formatDate = (date) => {
    if (!date) {
      return "";
    }

    try {
      return new Date(
        date
      ).toLocaleDateString(
        "en-IN",
        {
          day: "2-digit",
          month: "short",
          year: "numeric",
        }
      );
    } catch {
      return "";
    }
  };

  /*
    =====================================================
    UI
    =====================================================
  */

  return (
    <div className="admin-page">

      <header className="admin-hero">

        <div className="hero-orb hero-orb-one"></div>
        <div className="hero-orb hero-orb-two"></div>

        <div className="hero-grid">

          <div className="hero-content">

            <div className="hero-badge">
              ADMINISTRATION PANEL

              <span className="hero-live">
                LIVE
              </span>
            </div>

            <h1>
              Welcome back,{" "}
              <span>Admin</span>
            </h1>

            <p>
              Manage your sanctuary, review
              adoption applications and stay
              connected with your community
              from one powerful dashboard.
            </p>

            <div className="hero-actions">

              <button
                type="button"
                className="hero-button"
                onClick={loadDashboardData}
                disabled={loading}
              >
                {loading
                  ? "Loading..."
                  : "↻ Refresh Data"}
              </button>

              <button
                type="button"
                className="hero-logout"
                onClick={handleLogout}
              >
                ↪ Logout
              </button>

            </div>

          </div>

        </div>

      </header>

      <main className="admin-content">

        <div className="section-heading">

          <div className="section-label">
            SANCTUARY OVERVIEW
          </div>

          <h2>
            Dashboard Overview
          </h2>

          <p>
            A quick look at everything happening
            in your sanctuary.
          </p>

          <div className="admin-access">
            <span>●</span>
            Admin access
          </div>

        </div>

        {error && (
          <div className="dashboard-error">
            {error}
          </div>
        )}

        <section className="stats-grid">

          <div className="stat-card">

            <div className="stat-icon">
              🏠
            </div>

            <div className="stat-label">
              ADOPTIONS
            </div>

            <div className="stat-number">
              {loading
                ? "..."
                : stats.adoptions}
            </div>

            <div className="stat-description">
              Total adoption applications
            </div>

            <Link
              to="/admin/adoption-requests"
              className="stat-link"
            >
              View applications →
            </Link>

          </div>

          <div className="stat-card">

            <div className="stat-icon">
              🧡
            </div>

            <div className="stat-label">
              VOLUNTEERS
            </div>

            <div className="stat-number">
              {loading
                ? "..."
                : stats.volunteers}
            </div>

            <div className="stat-description">
              People supporting the sanctuary
            </div>

            <Link
              to="/admin/volunteer-requests"
              className="stat-link"
            >
              View volunteers →
            </Link>

          </div>

          <div className="stat-card">

            <div className="stat-icon">
              💬
            </div>

            <div className="stat-label">
              MESSAGES
            </div>

            <div className="stat-number">
              {loading
                ? "..."
                : stats.messages}
            </div>

            <div className="stat-description">
              Contact messages received
            </div>

            <Link
              to="/admin/messages"
              className="stat-link"
            >
              View messages →
            </Link>

          </div>

        </section>

        <section className="dashboard-grid">

          <div className="dashboard-card">

            <div className="card-header">

              <div>

                <div className="card-label">
                  APPLICATION OVERVIEW
                </div>

                <h3>
                  Recent Adoption Applications
                </h3>

                <p>
                  Review the latest people
                  interested in adopting a dog.
                </p>

              </div>

              <Link
                to="/admin/adoption-requests"
                className="manage-link"
              >
                Manage all →
              </Link>

            </div>

            <div className="recent-list">

              {loading ? (

                <div className="empty-state">

                  <div className="empty-state-icon">
                    🐾
                  </div>

                  <p>
                    Loading applications...
                  </p>

                </div>

              ) : recentAdoptions.length === 0 ? (

                <div className="empty-state">

                  <div className="empty-state-icon">
                    🐾
                  </div>

                  <p>
                    No adoption applications yet.
                  </p>

                </div>

              ) : (

                recentAdoptions.map(
                  (item) => (

                    <div
                      className="recent-item"
                      key={item._id}
                    >

                      <div className="recent-left">

                        <div className="recent-avatar">
                          🐶
                        </div>

                        <div>

                          <div className="recent-name">
                            {item.name}
                          </div>

                          <div className="recent-info">
                            Interested in adopting{" "}
                            <strong>
                              {item.dog}
                            </strong>
                            {" • "}
                            {formatDate(
                              item.createdAt
                            )}
                          </div>

                        </div>

                      </div>

                      <span
                        className={`status ${
                          String(
                            item.status
                          ).toLowerCase() ===
                          "approved"
                            ? "status-approved"
                            : String(
                                item.status
                              ).toLowerCase() ===
                              "rejected"
                            ? "status-rejected"
                            : "status-pending"
                        }`}
                      >
                        {item.status}
                      </span>

                    </div>

                  )
                )

              )}

            </div>

          </div>

          <div className="dashboard-card">

            <div className="card-label">
              MANAGEMENT
            </div>

            <h3>
              Quick Actions
            </h3>

            <p>
              Manage your sanctuary quickly.
            </p>

            <div className="quick-actions">

              <Link
                to="/admin/adoption-requests"
                className="quick-action"
              >
                <span>
                  🏠 Review Applications
                </span>

                <span>
                  →
                </span>
              </Link>

              <Link
                to="/admin/volunteer-requests"
                className="quick-action"
              >
                <span>
                  🤝 Manage Volunteers
                </span>

                <span>
                  →
                </span>
              </Link>

              <Link
                to="/admin/messages"
                className="quick-action"
              >
                <span>
                  💬 View Messages
                </span>

                <span>
                  →
                </span>
              </Link>

            </div>

          </div>

        </section>

        <section className="system-card">

          <div>

            <div className="card-label">
              SYSTEM STATUS
            </div>

            <h3>
              Sanctuary System
            </h3>

            <p>
              Everything is running normally.
            </p>

          </div>

          <div className="status-live">

            <span></span>

            SYSTEM LIVE

          </div>

        </section>

      </main>

    </div>
  );
}

export default AdminDashboard;
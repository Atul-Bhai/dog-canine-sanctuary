import React from "react";

import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  Link,
  useLocation,
  useNavigate,
} from "react-router-dom";

import "./App.css";

// Main pages
import Home from "./home";
import About from "./about";
import Care from "./care";
import Rescue from "./rescue";
import Adoption from "./adoption";
import Donation from "./donation";
import Volunteer from "./volunteer";
import Contact from "./contact";

// Authentication
import Login from "./login";
import Signup from "./signup";
import ForgotPassword from "./ForgotPaassword";

// Admin
import AdminDashboard from "./AdminDashboard";
import AdoptionRequests from "./AdoptionRequests";
import VolunteerRequests from "./VolunteerRequests";
import Message from "./message";

/* =========================================================
   ADMIN EMAILS
========================================================= */

const ADMIN_EMAILS = [
  "kanhaiya121@gmail.com",
  "atul7179@gmail.com",
  "sumit77@gmail.com",
];

/* =========================================================
   AUTH HELPERS
========================================================= */

function getAuthData() {
  const isLoggedIn =
    localStorage.getItem("isLoggedIn") === "true";

  const userEmail = (
    localStorage.getItem("userEmail") || ""
  )
    .trim()
    .toLowerCase();

  const userRole =
    localStorage.getItem("userRole") || "";

  const isAdminStorage =
    localStorage.getItem("isAdmin") === "true";

  const token =
    localStorage.getItem("token") ||
    localStorage.getItem("adminToken");

  let user = null;

  try {
    const storedUser =
      localStorage.getItem("user");

    if (storedUser) {
      user = JSON.parse(storedUser);
    }
  } catch (error) {
    console.error(
      "User data parse error:",
      error
    );
  }

  const userObjectEmail = (
    user?.email || ""
  )
    .trim()
    .toLowerCase();

  const finalEmail =
    userEmail ||
    userObjectEmail;

  const isAdminEmail =
    ADMIN_EMAILS.includes(finalEmail);

  const isAdmin =
    isAdminEmail ||
    userRole === "admin" ||
    isAdminStorage ||
    user?.role === "admin" ||
    user?.userRole === "admin" ||
    user?.isAdmin === true;

  return {
    isLoggedIn,
    isAdmin,
    userEmail: finalEmail,
    userRole: isAdmin ? "admin" : "user",
    user,
    token,
  };
}

/* =========================================================
   NAVBAR
========================================================= */

function Navbar() {
  const location = useLocation();
  const navigate = useNavigate();

  const {
    isLoggedIn,
    isAdmin,
  } = getAuthData();

  const navItems = [
    { name: "Home", path: "/" },
    { name: "About", path: "/about" },
    { name: "Care", path: "/care" },
    { name: "Rescue", path: "/rescue" },
    { name: "Adoption", path: "/adoption" },
    { name: "Donate", path: "/donate" },
    { name: "Volunteer", path: "/volunteer" },
    { name: "Contact", path: "/contact" },
  ];

  const handleLogout = () => {
    localStorage.removeItem("isLoggedIn");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("userRole");
    localStorage.removeItem("isAdmin");
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    localStorage.removeItem("adminToken");

    navigate("/", {
      replace: true,
    });

    window.location.reload();
  };

  return (
    <nav className="main-navbar">

      <Link
        to="/"
        className="navbar-logo"
      >
        <img
          src="/logo.jpeg"
          alt="Dog Canine Sanctuary"
        />

        <div className="navbar-brand-text">
          <strong>
            Dog Canine
          </strong>

          <span>
            Sanctuary
          </span>
        </div>
      </Link>

      <div className="navbar-links">

        {navItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={
              location.pathname === item.path
                ? "navbar-link active"
                : "navbar-link"
            }
          >
            {item.name}
          </Link>
        ))}

      </div>

      <div className="navbar-actions">

        {!isLoggedIn ? (
          <>
            <Link
              to="/login"
              className="navbar-login"
            >
              Login
            </Link>

            <Link
              to="/signup"
              className="navbar-signup"
            >
              Sign Up
            </Link>
          </>
        ) : (
          <>
            {isAdmin && (
              <Link
                to="/admin"
                className="navbar-dashboard"
              >
                Dashboard
              </Link>
            )}

            <button
              type="button"
              className="navbar-logout"
              onClick={handleLogout}
            >
              Logout
            </button>
          </>
        )}

      </div>

    </nav>
  );
}

/* =========================================================
   PROTECTED ROUTE
========================================================= */

function ProtectedRoute({
  children,
  adminOnly = false,
}) {
  const {
    isLoggedIn,
    isAdmin,
    token,
    userEmail,
  } = getAuthData();

  console.log(
    "PROTECTED ROUTE:",
    {
      isLoggedIn,
      isAdmin,
      tokenExists: !!token,
      userEmail,
    }
  );

  if (!isLoggedIn || !token) {
    return (
      <Navigate
        to="/login"
        replace
      />
    );
  }

  if (
    adminOnly &&
    !isAdmin
  ) {
    return (
      <Navigate
        to="/"
        replace
      />
    );
  }

  return children;
}

/* =========================================================
   APP CONTENT
========================================================= */

function AppContent() {
  const location =
    useLocation();

  const hideNavbar =
    location.pathname === "/login" ||
    location.pathname === "/signup" ||
    location.pathname === "/forgot-password" ||
    location.pathname.startsWith("/admin");

  return (
    <>
      {!hideNavbar && <Navbar />}

      <Routes>

        {/* PUBLIC */}

        <Route
          path="/"
          element={<Home />}
        />

        <Route
          path="/about"
          element={<About />}
        />

        <Route
          path="/care"
          element={<Care />}
        />

        <Route
          path="/rescue"
          element={<Rescue />}
        />

        <Route
          path="/adoption"
          element={<Adoption />}
        />

        <Route
          path="/donate"
          element={<Donation />}
        />

        <Route
          path="/donation"
          element={<Donation />}
        />

        <Route
          path="/volunteer"
          element={<Volunteer />}
        />

        <Route
          path="/contact"
          element={<Contact />}
        />

        {/* AUTH */}

        <Route
          path="/login"
          element={<Login />}
        />

        <Route
          path="/signup"
          element={<Signup />}
        />

        <Route
          path="/forgot-password"
          element={<ForgotPassword />}
        />

        {/* ADMIN DASHBOARD */}

        <Route
          path="/admin"
          element={
            <ProtectedRoute adminOnly={true}>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/admin/dashboard"
          element={
            <ProtectedRoute adminOnly={true}>
              <AdminDashboard />
            </ProtectedRoute>
          }
        />

        {/* ADMIN ADOPTION */}

        <Route
          path="/admin/adoption-requests"
          element={
            <ProtectedRoute adminOnly={true}>
              <AdoptionRequests />
            </ProtectedRoute>
          }
        />

        {/* ADMIN VOLUNTEERS */}

        <Route
          path="/admin/volunteer-requests"
          element={
            <ProtectedRoute adminOnly={true}>
              <VolunteerRequests />
            </ProtectedRoute>
          }
        />

        {/* ADMIN MESSAGES */}

        <Route
          path="/admin/messages"
          element={
            <ProtectedRoute adminOnly={true}>
              <Message />
            </ProtectedRoute>
          }
        />

        {/* UNKNOWN */}

        <Route
          path="*"
          element={
            <Navigate
              to="/"
              replace
            />
          }
        />

      </Routes>
    </>
  );
}

/* =========================================================
   MAIN APP
========================================================= */

function App() {
  return (
    <BrowserRouter>
      <AppContent />
    </BrowserRouter>
  );
}

export default App;
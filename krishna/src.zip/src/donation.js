import "./donation.css";

function Donate() {
  const donate = (amount) => {
    alert(
      `Thank you for choosing to donate ₹${amount}. Payment gateway can be connected here.`
    );
  };

  const amounts = [500, 1000, 2000, 5000];

  return (
    <section className="donate-page">

      <div className="donate-container">

        {/* ================= HERO ================= */}

        <div className="donate-hero">

          {/* LEFT */}

          <div className="donate-hero-content">

            <div className="donate-eyebrow">
              ❤️ SUPPORT • CARE • SAVE
            </div>

            <h1>
              Your Kindness
              <span> Gives Them Hope.</span>
            </h1>

            <p>
              Every donation helps us provide rescued dogs
              with nutritious food, medical treatment,
              safe shelter and the love they deserve.
            </p>

            <div className="donate-hero-buttons">

              <a href="#donation-options">
                Donate Now
                <span>→</span>
              </a>

              <a
                href="#upi-donation"
                className="donate-secondary-btn"
              >
                View UPI Details
              </a>

            </div>

            <div className="donate-trust">

              <div className="donate-trust-item">
                <strong>100%</strong>
                <span>For Dogs</span>
              </div>

              <div className="donate-trust-line"></div>

              <div className="donate-trust-item">
                <strong>24/7</strong>
                <span>Care</span>
              </div>

              <div className="donate-trust-line"></div>

              <div className="donate-trust-item">
                <strong>🐾</strong>
                <span>Love</span>
              </div>

            </div>

          </div>


          {/* RIGHT VISUAL */}

          <div className="donate-visual">

            <div className="donate-glow donate-glow-one"></div>
            <div className="donate-glow donate-glow-two"></div>

            <div className="donate-orbit donate-orbit-one"></div>
            <div className="donate-orbit donate-orbit-two"></div>

            <div className="donate-dog-frame">

              <img
                src="https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&w=900&q=85"
                alt="Happy rescued dog"
              />

            </div>


            {/* FLOATING CARD 1 */}

            <div className="donate-floating-card donate-card-top">

              <div className="donate-floating-icon">
                ❤️
              </div>

              <div>
                <strong>
                  Every ₹500
                </strong>

                <span>
                  Makes a difference
                </span>
              </div>

            </div>


            {/* FLOATING CARD 2 */}

            <div className="donate-floating-card donate-card-bottom">

              <div className="donate-paw">
                🐾
              </div>

              <div>
                <strong>
                  Give them a chance
                </strong>

                <span>
                  One donation at a time
                </span>
              </div>

            </div>


            <div className="donate-visual-badge">
              🐶
            </div>

          </div>

        </div>


        {/* ================= DONATION OPTIONS ================= */}

        <div
          className="donation-options"
          id="donation-options"
        >

          <div className="donation-heading">

            <div>
              <span>
                CHOOSE YOUR SUPPORT
              </span>

              <h2>
                Make a Difference Today
              </h2>
            </div>

            <p>
              Your contribution directly supports the
              daily care of our rescued dogs.
            </p>

          </div>


          <div className="donation-grid">

            {amounts.map((amount, index) => (

              <div
                className={`donation-card ${
                  index === 2 ? "donation-card-featured" : ""
                }`}
                key={amount}
              >

                {index === 2 && (
                  <div className="donation-popular">
                    MOST NEEDED
                  </div>
                )}

                <div className="donation-icon">
                  ❤️
                </div>

                <div className="donation-amount">
                  ₹{amount}
                </div>

                <p>
                  Help provide food, medicine and
                  daily care for a rescued dog.
                </p>

                <button
                  onClick={() => donate(amount)}
                >
                  Donate ₹{amount}
                  <span>→</span>
                </button>

              </div>

            ))}

          </div>

        </div>


        {/* ================= UPI ================= */}

        <div
          className="upi-donation"
          id="upi-donation"
        >

          <div className="upi-content">

            <div className="upi-icon">
              ₹
            </div>

            <div>

              <span>
                QUICK & SECURE
              </span>

              <h2>
                Donate Through UPI
              </h2>

              <p>
                Use your preferred UPI app to directly
                support our rescued dogs.
              </p>

              <div className="upi-id">
                <small>UPI ID</small>

                <strong>
                  dogcanine@upi
                </strong>

                <button
                  onClick={() =>
                    navigator.clipboard?.writeText(
                      "dogcanine@upi"
                    )
                  }
                >
                  Copy
                </button>
              </div>

            </div>

          </div>


          <div className="upi-heart">
            ❤️
          </div>

        </div>


        {/* ================= FOOTER MESSAGE ================= */}

        <div className="donate-bottom">

          <span>🐾</span>

          <h3>
            One small act of kindness can change a life.
          </h3>

          <p>
            Thank you for standing beside our rescued dogs.
          </p>

        </div>

      </div>

    </section>
  );
}

export default Donate;
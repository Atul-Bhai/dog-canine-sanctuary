import {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import { Link, useNavigate } from "react-router-dom";
import "./VolunteerRequests.css";

const API = "http://localhost:5000/api";

function VolunteerRequests() {
  const navigate = useNavigate();

  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");
  const [deletingId, setDeletingId] = useState(null);
  const [search, setSearch] = useState("");

  // =====================================================
  // GET AUTH TOKEN
  // =====================================================

  const getAuthToken = useCallback(() => {
    return (
      localStorage.getItem("token") ||
      localStorage.getItem("adminToken") ||
      null
    );
  }, []);

  // =====================================================
  // AUTHENTICATED FETCH
  // =====================================================

  const authenticatedFetch = useCallback(
    async (url, options = {}) => {
      const token = getAuthToken();

      if (!token) {
        localStorage.removeItem("user");
        localStorage.removeItem("token");
        localStorage.removeItem("adminToken");
        localStorage.removeItem("isAdmin");
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userRole");
        localStorage.removeItem("userEmail");

        navigate("/login", {
          replace: true,
        });

        throw new Error(
          "Your session has expired. Please login again."
        );
      }

      const existingHeaders =
        options.headers || {};

      const response = await fetch(url, {
        ...options,

        headers: {
          ...existingHeaders,

          Authorization: `Bearer ${token}`,

          ...(options.body &&
          !existingHeaders["Content-Type"]
            ? {
                "Content-Type":
                  "application/json",
              }
            : {}),
        },
      });

      if (
        response.status === 401 ||
        response.status === 403
      ) {
        localStorage.removeItem("user");
        localStorage.removeItem("token");
        localStorage.removeItem("adminToken");
        localStorage.removeItem("isAdmin");
        localStorage.removeItem("isLoggedIn");
        localStorage.removeItem("userRole");
        localStorage.removeItem("userEmail");

        navigate("/login", {
          replace: true,
        });

        throw new Error(
          "Your session has expired. Please login again."
        );
      }

      return response;
    },
    [getAuthToken, navigate]
  );

  // =====================================================
  // LOAD VOLUNTEER APPLICATIONS
  // =====================================================

  const loadApplications = useCallback(
    async (showRefresh = false) => {
      try {
        if (showRefresh) {
          setRefreshing(true);
        } else {
          setLoading(true);
        }

        setError("");

        const response =
          await authenticatedFetch(
            `${API}/volunteer`
          );

        let data = {};

        try {
          data = await response.json();
        } catch {
          data = {};
        }

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Failed to load volunteer requests."
          );
        }

        const volunteerData =
          Array.isArray(data)
            ? data
            : data.applications ||
              data.volunteers ||
              data.data ||
              [];

        setApplications(
          volunteerData
        );
      } catch (error) {
        console.error(
          "Volunteer fetch error:",
          error
        );

        setError(
          error.message ||
            "Unable to connect to backend server."
        );
      } finally {
        setLoading(false);
        setRefreshing(false);
      }
    },
    [authenticatedFetch]
  );

  // =====================================================
  // DELETE
  // =====================================================

  const deleteApplication =
    async (id) => {
      const confirmDelete =
        window.confirm(
          "Are you sure you want to permanently delete this volunteer request?"
        );

      if (!confirmDelete) {
        return;
      }

      try {
        setDeletingId(id);
        setError("");

        const response =
          await authenticatedFetch(
            `${API}/volunteer/${id}`,
            {
              method: "DELETE",
            }
          );

        let data = {};

        try {
          data = await response.json();
        } catch {
          data = {};
        }

        if (!response.ok) {
          throw new Error(
            data.message ||
              "Failed to delete volunteer request."
          );
        }

        setApplications(
          (previous) =>
            previous.filter(
              (item) =>
                item._id !== id
            )
        );
      } catch (error) {
        console.error(
          "Delete volunteer error:",
          error
        );

        setError(
          error.message ||
            "Unable to delete volunteer request."
        );
      } finally {
        setDeletingId(null);
      }
    };

  // =====================================================
  // INITIAL LOAD
  // =====================================================

  useEffect(() => {
    loadApplications();
  }, [loadApplications]);

  // =====================================================
  // SEARCH
  // =====================================================

  const filteredApplications =
    useMemo(() => {
      const value =
        search.trim().toLowerCase();

      if (!value) {
        return applications;
      }

      return applications.filter(
        (item) =>
          [
            item.name,
            item.email,
            item.phone,
            item.activity,
          ]
            .filter(Boolean)
            .some((field) =>
              String(field)
                .toLowerCase()
                .includes(value)
            )
      );
    }, [applications, search]);

  // =====================================================
  // DATE
  // =====================================================

  const formatDate = (date) => {
    if (!date) {
      return "Date unavailable";
    }

    const parsedDate =
      new Date(date);

    if (
      Number.isNaN(
        parsedDate.getTime()
      )
    ) {
      return "Date unavailable";
    }

    return parsedDate.toLocaleString();
  };

  // =====================================================
  // PAGE
  // =====================================================

  return (
    <div className="volunteer-admin-page">

      <section className="volunteer-admin-hero">

        <div className="volunteer-hero-glow volunteer-glow-one"></div>
        <div className="volunteer-hero-glow volunteer-glow-two"></div>

        <div className="volunteer-hero-inner">

          <div>

            <div className="volunteer-eyebrow">
              <span></span>
              ADMINISTRATION
            </div>

            <h1>
              Volunteer Requests
            </h1>

            <p>
              Review and manage everyone who has
              registered to support your sanctuary.
            </p>

          </div>

          <div className="volunteer-hero-actions">

            <button
              type="button"
              className="volunteer-refresh-btn"
              onClick={() =>
                loadApplications(true)
              }
              disabled={
                refreshing || loading
              }
            >
              <span
                className={
                  refreshing
                    ? "spin"
                    : ""
                }
              >
                ↻
              </span>

              {refreshing
                ? "Refreshing..."
                : "Refresh"}
            </button>

            <Link
              to="/admin"
              className="volunteer-dashboard-btn"
            >
              ← Dashboard
            </Link>

          </div>

        </div>
      </section>

      <main className="volunteer-admin-content">

        <section className="volunteer-stats">

          <div className="volunteer-stat-card stat-orange">

            <div className="volunteer-stat-icon">
              🤝
            </div>

            <div>

              <div className="volunteer-stat-label">
                TOTAL VOLUNTEERS
              </div>

              <div className="volunteer-stat-number">
                {loading
                  ? "—"
                  : applications.length}
              </div>

              <div className="volunteer-stat-description">
                Registrations received
              </div>

            </div>

          </div>

          <div className="volunteer-stat-card stat-blue">

            <div className="volunteer-stat-icon">
              🐾
            </div>

            <div>

              <div className="volunteer-stat-label">
                SHOWING
              </div>

              <div className="volunteer-stat-number">
                {loading
                  ? "—"
                  : filteredApplications.length}
              </div>

              <div className="volunteer-stat-description">
                Matching requests
              </div>

            </div>

          </div>

          <div className="volunteer-stat-card stat-green">

            <div className="volunteer-stat-icon">
              ✓
            </div>

            <div>

              <div className="volunteer-stat-label">
                STATUS
              </div>

              <div className="volunteer-stat-word">
                ACTIVE
              </div>

              <div className="volunteer-stat-description">
                Volunteer system is live
              </div>

            </div>

          </div>

        </section>

        <section className="volunteer-toolbar">

          <div className="volunteer-search">

            <span>⌕</span>

            <input
              type="text"
              placeholder="Search name, email, phone or activity..."
              value={search}
              onChange={(event) =>
                setSearch(
                  event.target.value
                )
              }
            />

            {search && (
              <button
                type="button"
                className="clear-search"
                onClick={() =>
                  setSearch("")
                }
                aria-label="Clear search"
              >
                ×
              </button>
            )}

          </div>

          <div className="volunteer-result-count">
            {loading
              ? "Loading..."
              : `Showing ${filteredApplications.length} of ${applications.length}`}
          </div>

        </section>

        {error && (
          <div className="volunteer-error">

            <div>

              <strong>
                Unable to load requests
              </strong>

              <p>
                {error}
              </p>

            </div>

            <button
              type="button"
              onClick={() =>
                loadApplications()
              }
            >
              Try Again
            </button>

          </div>
        )}

        {loading && !error && (
          <div className="volunteer-loading">

            <div className="loading-spinner"></div>

            <h3>
              Loading volunteer requests...
            </h3>

            <p>
              Please wait while we fetch the latest
              registrations.
            </p>

          </div>
        )}

        {!loading &&
          !error &&
          filteredApplications.length === 0 && (
            <div className="volunteer-empty">

              <div className="volunteer-empty-icon">
                {search ? "⌕" : "🤝"}
              </div>

              <h3>
                {search
                  ? "No matching volunteers"
                  : "No volunteer requests yet"}
              </h3>

              <p>
                {search
                  ? "Try a different search term."
                  : "Volunteer registrations will appear here when visitors sign up."}
              </p>

              {search && (
                <button
                  type="button"
                  onClick={() =>
                    setSearch("")
                  }
                >
                  Clear Search
                </button>
              )}

            </div>
          )}

        {!loading &&
          !error &&
          filteredApplications.length > 0 && (

            <section className="volunteer-list-section">

              <div className="volunteer-list-heading">

                <div>

                  <div className="volunteer-section-label">
                    VOLUNTEER MANAGEMENT
                  </div>

                  <h2>
                    Registered Volunteers
                  </h2>

                  <p>
                    Review contact details and preferred
                    volunteer activities.
                  </p>

                </div>

              </div>

              <div className="volunteer-list">

                {filteredApplications.map(
                  (item) => {

                    const isDeleting =
                      deletingId ===
                      item._id;

                    return (
                      <article
                        className="volunteer-request-card"
                        key={item._id}
                      >

                        <div className="volunteer-card-top">

                          <div className="volunteer-person">

                            <div className="volunteer-avatar">
                              {item.name
                                ? item.name
                                    .charAt(0)
                                    .toUpperCase()
                                : "V"}
                            </div>

                            <div>

                              <div className="volunteer-person-label">
                                VOLUNTEER
                              </div>

                              <h3>
                                {item.name ||
                                  "Unknown Volunteer"}
                              </h3>

                              <div className="volunteer-id">
                                ID:{" "}
                                {item._id ||
                                  "N/A"}
                              </div>

                            </div>

                          </div>

                          <span className="volunteer-status">
                            <span></span>
                            Active
                          </span>

                        </div>

                        <div className="volunteer-details">

                          <div className="volunteer-detail">

                            <div className="detail-icon">
                              ✉
                            </div>

                            <div>
                              <span>
                                EMAIL
                              </span>

                              <strong>
                                {item.email ||
                                  "Not provided"}
                              </strong>
                            </div>

                          </div>

                          <div className="volunteer-detail">

                            <div className="detail-icon">
                              ☎
                            </div>

                            <div>
                              <span>
                                PHONE
                              </span>

                              <strong>
                                {item.phone ||
                                  "Not provided"}
                              </strong>
                            </div>

                          </div>

                          <div className="volunteer-detail">

                            <div className="detail-icon">
                              🐾
                            </div>

                            <div>
                              <span>
                                INTERESTED IN
                              </span>

                              <strong>
                                {item.activity ||
                                  "General volunteering"}
                              </strong>
                            </div>

                          </div>

                          <div className="volunteer-detail">

                            <div className="detail-icon">
                              ◷
                            </div>

                            <div>
                              <span>
                                SUBMITTED
                              </span>

                              <strong>
                                {formatDate(
                                  item.createdAt
                                )}
                              </strong>
                            </div>

                          </div>

                        </div>

                        <div className="volunteer-card-footer">

                          <div className="volunteer-current-status">

                            <span></span>

                            Current status:{" "}

                            <strong>
                              Active
                            </strong>

                          </div>

                          <button
                            type="button"
                            className="volunteer-delete-btn"
                            onClick={() =>
                              deleteApplication(
                                item._id
                              )
                            }
                            disabled={
                              isDeleting
                            }
                          >
                            {isDeleting
                              ? "Deleting..."
                              : "× Delete Request"}
                          </button>

                        </div>

                      </article>
                    );
                  }
                )}

              </div>

            </section>
          )}

      </main>

    </div>
  );
}

export default VolunteerRequests;